<x-filament-panels::page>
<div class="mx-auto max-w-4xl p-6 space-y-6">

    {{-- ─── Tarjeta de Registro ────────────────────────────────────────────── --}}
    <x-filament::section>
        <x-slot name="heading">
            <div class="flex items-center gap-2">
                <x-filament::icon icon="heroicon-o-identification" class="h-5 w-5 text-primary-500" />
                <span>Registro de Asistencia</span>
            </div>
        </x-slot>
        <x-slot name="description">
            Ingrese el DNI del cliente (8 dígitos) y presione Enter para registrar la entrada.
        </x-slot>

        <div class="flex flex-col items-center py-6 space-y-4">
            <div class="w-full max-w-sm">
                <x-filament::input.wrapper>
                    <x-filament::input
                        type="text"
                        wire:model.defer="dni"
                        wire:keydown.enter="registrarDni"
                        id="dni-input"
                        placeholder="12345678"
                        maxlength="8"
                        inputmode="numeric"
                        autofocus
                        oninput="this.value=this.value.replace(/[^0-9]/g,'').slice(0,8)"
                        style="text-align:center;font-size:1.3rem;font-family:monospace;letter-spacing:.3em;font-weight:800;padding:.7rem 1rem;"
                    />
                </x-filament::input.wrapper>
            </div>
            <div class="w-full max-w-sm">
                <x-filament::button wire:click="registrarDni" size="lg" class="w-full">
                    Registrar Entrada
                </x-filament::button>
            </div>
        </div>
    </x-filament::section>

    {{-- ─── ACCESO PERMITIDO ───────────────────────────────────────────────── --}}
    @if(session()->has('acceso_permitido'))
    @php $ok = session('acceso_permitido'); @endphp
    <div class="flex gap-5 p-5 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 border-l-4 border-emerald-500 shadow-sm">

        {{-- Icono --}}
        <div class="shrink-0 flex items-center justify-center w-14 h-14 rounded-full bg-emerald-100 dark:bg-emerald-900/50">
            <x-filament::icon icon="heroicon-s-check-badge" class="h-9 w-9 text-emerald-600 dark:text-emerald-400" />
        </div>

        {{-- Texto --}}
        <div class="flex-1 min-w-0 space-y-2">
            <p class="text-sm font-bold uppercase tracking-widest text-emerald-700 dark:text-emerald-400">
                Acceso Permitido
            </p>
            <p class="text-xl font-extrabold text-gray-900 dark:text-white leading-tight truncate">
                {{ $ok['nombre'] }}
            </p>

            {{-- Pastillas de detalle --}}
            <div class="flex flex-wrap gap-2 pt-1">
                <span class="bg-emerald-100 text-emerald-800 dark:bg-emerald-900/50 dark:text-emerald-300 text-xs px-2.5 py-1 rounded-md font-semibold">
                    Plan: {{ $ok['plan'] }}
                </span>
                <span class="bg-emerald-100 text-emerald-800 dark:bg-emerald-900/50 dark:text-emerald-300 text-xs px-2.5 py-1 rounded-md font-semibold">
                    Vence: {{ $ok['vence'] }}
                </span>
                <span class="text-xs px-2.5 py-1 rounded-md font-semibold
                    {{ $ok['alerta']
                        ? 'bg-amber-100 text-amber-800 dark:bg-amber-900/50 dark:text-amber-300'
                        : 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/50 dark:text-emerald-300' }}">
                    {{ $ok['dias'] }} día(s) restante(s){{ $ok['alerta'] ? ' ⚠' : '' }}
                </span>
            </div>
        </div>

    </div>
    @endif

    {{-- ─── ACCESO DENEGADO ────────────────────────────────────────────────── --}}
    @if(session()->has('acceso_denegado'))
    @php $ko = session('acceso_denegado'); @endphp
    <div class="flex gap-5 p-5 rounded-xl bg-rose-50 dark:bg-rose-950/30 border-l-4 border-rose-500 shadow-sm">

        {{-- Icono --}}
        <div class="shrink-0 flex items-center justify-center w-14 h-14 rounded-full bg-rose-100 dark:bg-rose-900/50">
            <x-filament::icon icon="heroicon-s-x-circle" class="h-9 w-9 text-rose-600 dark:text-rose-400" />
        </div>

        {{-- Texto --}}
        <div class="flex-1 min-w-0 space-y-2">
            <p class="text-sm font-bold uppercase tracking-widest text-rose-700 dark:text-rose-400">
                Acceso Denegado
            </p>
            <p class="text-xl font-extrabold text-gray-900 dark:text-white leading-tight truncate">
                {{ $ko['nombre'] ?? 'DNI NO REGISTRADO' }}
            </p>
            <span class="inline-block bg-rose-100 text-rose-800 dark:bg-rose-900/50 dark:text-rose-300 text-xs px-2.5 py-1 rounded-md font-bold uppercase tracking-wide">
                {{ $ko['razon'] }}
            </span>
        </div>

    </div>
    @endif

    {{-- ─── Asistencias de Hoy ─────────────────────────────────────────────── --}}
    <x-filament::section>
        <x-slot name="heading">
            <div class="flex items-center justify-between w-full">
                <span>Asistencias de Hoy</span>
                <x-filament::badge color="gray">
                    {{ $this->asistencias->count() }} {{ $this->asistencias->count() === 1 ? 'persona' : 'personas' }}
                </x-filament::badge>
            </div>
        </x-slot>

        <div class="space-y-3 mt-2">
            @forelse($this->asistencias as $asistencia)
                <div class="flex items-center justify-between p-4 bg-white dark:bg-gray-900 rounded-xl border border-gray-100 dark:border-gray-800 shadow-sm transition hover:shadow-md">

                    {{-- Avatar + info --}}
                    <div class="flex items-center gap-3 min-w-0">
                        {{-- Mini avatar --}}
                        <div class="shrink-0 flex items-center justify-center w-10 h-10 rounded-full bg-gray-100 dark:bg-gray-800 border border-gray-200 dark:border-gray-700">
                            <x-filament::icon icon="heroicon-s-user" class="h-5 w-5 text-gray-400 dark:text-gray-500" />
                        </div>
                        <div class="min-w-0">
                            <p class="text-sm font-bold text-gray-900 dark:text-white truncate">
                                {{ $asistencia->cliente->nombre_completo }}
                            </p>
                            <p class="text-xs font-mono text-gray-400 dark:text-gray-500">
                                DNI {{ $asistencia->cliente->dni }}
                            </p>
                        </div>
                    </div>

                    {{-- Hora + badge --}}
                    <div class="flex items-center gap-3 shrink-0">
                        <span class="text-sm font-bold font-mono text-gray-700 dark:text-gray-300">
                            {{ $asistencia->entrada_at->format('H:i') }}
                        </span>
                        <x-filament::badge color="success">Presente</x-filament::badge>
                    </div>

                </div>
            @empty
                <div class="flex flex-col items-center justify-center py-10 gap-3 text-center">
                    <div class="flex items-center justify-center w-14 h-14 rounded-full bg-gray-100 dark:bg-gray-800">
                        <x-filament::icon icon="heroicon-o-users" class="h-7 w-7 text-gray-300 dark:text-gray-600" />
                    </div>
                    <div>
                        <p class="text-sm font-semibold text-gray-500 dark:text-gray-400">Sin asistencias registradas hoy</p>
                        <p class="text-xs text-gray-400 dark:text-gray-500 mt-0.5">Los registros aparecerán aquí al ingresar un DNI.</p>
                    </div>
                </div>
            @endforelse
        </div>

    </x-filament::section>

</div>

<script>
    document.addEventListener('livewire:initialized', () => {
        document.getElementById('dni-input')?.focus();
        Livewire.hook('morph.updated', () => {
            setTimeout(() => document.getElementById('dni-input')?.focus(), 150);
        });
    });
</script>
</x-filament-panels::page>

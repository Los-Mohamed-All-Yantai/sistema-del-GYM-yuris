<x-filament-panels::page>
@php
    $resumen  = $this->getResumenMes();
    $total    = $resumen['ingresos_membresias'] + $resumen['ingresos_ventas'];
    $mesLabel = ucfirst(now()->locale('es')->translatedFormat('F Y'));
@endphp

<div class="fi-resource-pages-list-records-page mx-auto max-w-5xl p-6 space-y-6">

    {{-- ═══════════════════════════════════════════════════════════════════════
         RESUMEN DEL MES
    ════════════════════════════════════════════════════════════════════════ --}}
    <x-filament::section>
        <x-slot name="heading">
            <div class="flex items-center justify-between w-full">
                <div class="flex items-center gap-2">
                    <x-filament::icon icon="heroicon-o-chart-bar" class="h-5 w-5 text-primary-500" />
                    <span>Resumen del Mes Actual</span>
                </div>
                <x-filament::badge color="gray">{{ $mesLabel }}</x-filament::badge>
            </div>
        </x-slot>
        <x-slot name="description">
            Estadísticas acumuladas de inscripciones y ventas en el mes en curso.
        </x-slot>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mt-4">

            {{-- ── Tarjeta 1: Inscripciones ─────────────────────────────── --}}
            <div class="relative flex flex-col justify-between p-6 rounded-2xl bg-white dark:bg-gray-900
                        border border-gray-100 dark:border-gray-800 shadow-sm overflow-hidden">
                {{-- Acento de color arriba --}}
                <div class="absolute inset-x-0 top-0 h-1 rounded-t-2xl bg-primary-500"></div>

                {{-- Cabecera --}}
                <div class="flex items-center justify-between mb-4">
                    <p class="text-xs font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500">
                        Nuevas Inscripciones
                    </p>
                    <div class="flex items-center justify-center w-9 h-9 rounded-xl bg-primary-50 dark:bg-primary-900/40">
                        <x-filament::icon icon="heroicon-o-user-plus" class="h-5 w-5 text-primary-600 dark:text-primary-400" />
                    </div>
                </div>

                {{-- Número grande --}}
                <p class="text-5xl font-extrabold text-primary-700 dark:text-primary-300 leading-none mb-4">
                    {{ $resumen['inscripciones'] }}
                </p>

                {{-- Badge monto --}}
                <div>
                    <x-filament::badge color="primary" size="lg">
                        S/&nbsp;{{ number_format($resumen['ingresos_membresias'], 2) }}
                    </x-filament::badge>
                </div>
            </div>

            {{-- ── Tarjeta 2: Ventas de Productos ──────────────────────── --}}
            <div class="relative flex flex-col justify-between p-6 rounded-2xl bg-white dark:bg-gray-900
                        border border-gray-100 dark:border-gray-800 shadow-sm overflow-hidden">
                <div class="absolute inset-x-0 top-0 h-1 rounded-t-2xl bg-warning-500"></div>

                <div class="flex items-center justify-between mb-4">
                    <p class="text-xs font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500">
                        Ventas de Productos
                    </p>
                    <div class="flex items-center justify-center w-9 h-9 rounded-xl bg-warning-50 dark:bg-warning-900/40">
                        <x-filament::icon icon="heroicon-o-shopping-cart" class="h-5 w-5 text-warning-600 dark:text-warning-400" />
                    </div>
                </div>

                <p class="text-5xl font-extrabold text-warning-600 dark:text-warning-400 leading-none mb-4">
                    {{ $resumen['ventas_count'] }}
                </p>

                <div>
                    <x-filament::badge color="warning" size="lg">
                        S/&nbsp;{{ number_format($resumen['ingresos_ventas'], 2) }}
                    </x-filament::badge>
                </div>
            </div>

            {{-- ── Tarjeta 3: Ingresos Totales ──────────────────────────── --}}
            <div class="relative flex flex-col justify-between p-6 rounded-2xl bg-white dark:bg-gray-900
                        border border-gray-100 dark:border-gray-800 shadow-sm overflow-hidden">
                <div class="absolute inset-x-0 top-0 h-1 rounded-t-2xl bg-success-500"></div>

                <div class="flex items-center justify-between mb-4">
                    <p class="text-xs font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500">
                        Ingresos Totales
                    </p>
                    <div class="flex items-center justify-center w-9 h-9 rounded-xl bg-success-50 dark:bg-success-900/40">
                        <x-filament::icon icon="heroicon-o-banknotes" class="h-5 w-5 text-success-600 dark:text-success-400" />
                    </div>
                </div>

                <p class="text-4xl font-extrabold text-success-600 dark:text-success-400 leading-none mb-4">
                    S/ {{ number_format($total, 2) }}
                </p>

                {{-- Desglose por método de pago --}}
                <div class="pt-3 border-t border-gray-100 dark:border-gray-800 flex flex-col gap-1.5">
                    <div class="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400">
                        <span class="flex items-center gap-1.5">
                            <span class="inline-block w-2 h-2 rounded-full bg-gray-400"></span>
                            Efectivo
                        </span>
                        <span class="font-semibold text-gray-700 dark:text-gray-300 font-mono">
                            S/ {{ number_format($resumen['efectivo'], 2) }}
                        </span>
                    </div>
                    <div class="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400">
                        <span class="flex items-center gap-1.5">
                            <span class="inline-block w-2 h-2 rounded-full bg-primary-400"></span>
                            Digital
                        </span>
                        <span class="font-semibold text-gray-700 dark:text-gray-300 font-mono">
                            S/ {{ number_format($resumen['digital'], 2) }}
                        </span>
                    </div>
                </div>
            </div>

        </div>
    </x-filament::section>

    {{-- ═══════════════════════════════════════════════════════════════════════
         EXPORTAR CLIENTES
    ════════════════════════════════════════════════════════════════════════ --}}
    <x-filament::section>
        <x-slot name="heading">
            <div class="flex items-center gap-2">
                <x-filament::icon icon="heroicon-o-users" class="h-5 w-5 text-success-500" />
                <span>Exportar Clientes</span>
            </div>
        </x-slot>
        <x-slot name="description">
            Genera un archivo Excel con la lista completa de clientes, su plan y estado de membresía actual.
        </x-slot>

        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mt-2
                    p-4 rounded-xl bg-success-50 dark:bg-success-900/20
                    border border-success-200 dark:border-success-800">
            <div class="flex items-center gap-3">
                <div class="flex items-center justify-center w-10 h-10 rounded-lg
                            bg-success-100 dark:bg-success-900/50 shrink-0">
                    <x-filament::icon icon="heroicon-o-table-cells" class="h-5 w-5 text-success-700 dark:text-success-400" />
                </div>
                <div>
                    <p class="text-sm font-semibold text-success-800 dark:text-success-300">
                        clientes_{{ now()->format('Ymd') }}.xlsx
                    </p>
                    <p class="text-xs text-success-600 dark:text-success-500">
                        Nombre · DNI · Plan · Estado · Fecha de vencimiento
                    </p>
                </div>
            </div>

            <x-filament::button
                wire:click="exportarClientes"
                icon="heroicon-o-arrow-down-tray"
                color="success"
                class="shrink-0"
            >
                Descargar Excel
            </x-filament::button>
        </div>
    </x-filament::section>

    {{-- ═══════════════════════════════════════════════════════════════════════
         EXPORTAR VENTAS
    ════════════════════════════════════════════════════════════════════════ --}}
    <x-filament::section>
        <x-slot name="heading">
            <div class="flex items-center gap-2">
                <x-filament::icon icon="heroicon-o-shopping-bag" class="h-5 w-5 text-primary-500" />
                <span>Exportar Ventas por Fecha</span>
            </div>
        </x-slot>
        <x-slot name="description">
            Filtra por rango de fechas y descarga el detalle de ventas con productos, montos y métodos de pago.
        </x-slot>

        <div class="space-y-5 mt-2">

            {{-- Selector de rango --}}
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div class="space-y-1.5">
                    <label class="flex items-center gap-1.5 text-sm font-semibold text-gray-700 dark:text-gray-300">
                        <x-filament::icon icon="heroicon-o-calendar-days" class="h-4 w-4 text-gray-400" />
                        Desde
                    </label>
                    <x-filament::input.wrapper>
                        <x-filament::input type="date" wire:model="desde" />
                    </x-filament::input.wrapper>
                </div>
                <div class="space-y-1.5">
                    <label class="flex items-center gap-1.5 text-sm font-semibold text-gray-700 dark:text-gray-300">
                        <x-filament::icon icon="heroicon-o-calendar-days" class="h-4 w-4 text-gray-400" />
                        Hasta
                    </label>
                    <x-filament::input.wrapper>
                        <x-filament::input type="date" wire:model="hasta" />
                    </x-filament::input.wrapper>
                </div>
            </div>

            {{-- Info del archivo --}}
            <div class="flex items-start gap-3 px-4 py-3 rounded-xl
                        bg-gray-50 dark:bg-gray-800
                        border border-gray-200 dark:border-gray-700">
                <x-filament::icon icon="heroicon-o-information-circle" class="h-4 w-4 text-gray-400 shrink-0 mt-0.5" />
                <p class="text-xs text-gray-500 dark:text-gray-400">
                    El reporte incluirá todas las ventas <strong>completadas</strong> dentro del rango seleccionado:
                    productos, cantidades, precio unitario, total y método de pago.
                </p>
            </div>

            {{-- Botón descarga — ancho completo --}}
            <x-filament::button
                wire:click="exportarVentas"
                icon="heroicon-o-arrow-down-tray"
                color="info"
                class="w-full"
                size="lg"
            >
                Descargar Excel de Ventas
            </x-filament::button>

        </div>
    </x-filament::section>

</div>
</x-filament-panels::page>

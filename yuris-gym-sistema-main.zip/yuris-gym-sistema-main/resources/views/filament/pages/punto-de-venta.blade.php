<x-filament-panels::page>

<style>
/* ── Contenedor principal ── */
.pdv-grid {
    display: grid;
    grid-template-columns: 1fr;
    gap: 1.25rem;
}
@media (min-width: 1024px) {
    .pdv-grid { grid-template-columns: 2fr 1fr; }
}
.pdv-col-left  { display: flex; flex-direction: column; gap: 1.25rem; }
.pdv-col-right { display: flex; flex-direction: column; gap: 1.25rem; }

/* ── Tarjeta base ── */
.pdv-card {
    background: #ffffff;
    border: 1px solid #e5e7eb;
    border-radius: 1rem;
    overflow: hidden;
    box-shadow: 0 1px 3px 0 rgb(0 0 0 / .07);
}
html.dark .pdv-card {
    background: oklch(0.274 0.006 286.033); /* gray-800 */
    border-color: oklch(0.37 0.013 285.805); /* gray-700 */
}

/* ── Header de sección ── */
.pdv-section-header {
    display: flex;
    align-items: center;
    gap: .625rem;
    padding: 1rem 1rem .75rem;
    border-bottom: 1px solid #f3f4f6;
}
html.dark .pdv-section-header { border-bottom-color: oklch(0.37 0.013 285.805); }

.pdv-section-icon {
    width: 1.75rem; height: 1.75rem;
    border-radius: .5rem;
    display: flex; align-items: center; justify-content: center;
    flex-shrink: 0;
}
.pdv-section-icon svg { width: 1rem; height: 1rem; }

.pdv-icon-violet { background: #ede9fe; }
html.dark .pdv-icon-violet { background: oklch(0.381 0.176 293.745 / .35); }
.pdv-icon-violet svg { color: #7c3aed; }
html.dark .pdv-icon-violet svg { color: #a78bfa; }

.pdv-icon-blue { background: #dbeafe; }
html.dark .pdv-icon-blue { background: oklch(0.488 0.243 264.376 / .35); }
.pdv-icon-blue svg { color: #2563eb; }
html.dark .pdv-icon-blue svg { color: #60a5fa; }

.pdv-icon-orange { background: #ffedd5; }
html.dark .pdv-icon-orange { background: oklch(0.553 0.195 38.402 / .35); }
.pdv-icon-orange svg { color: #ea580c; }
html.dark .pdv-icon-orange svg { color: #fb923c; }

.pdv-icon-green { background: #dcfce7; }
html.dark .pdv-icon-green { background: oklch(0.527 0.154 150.069 / .35); }
.pdv-icon-green svg { color: #16a34a; }
html.dark .pdv-icon-green svg { color: #4ade80; }

.pdv-icon-teal { background: #ccfbf1; }
html.dark .pdv-icon-teal { background: oklch(0.511 0.096 186.391 / .35); }
.pdv-icon-teal svg { color: #0d9488; }
html.dark .pdv-icon-teal svg { color: #2dd4bf; }

.pdv-section-title {
    font-size: .875rem; font-weight: 600;
    color: #374151;
}
html.dark .pdv-section-title { color: #e5e7eb; }
.pdv-section-sub { font-size: .75rem; color: #9ca3af; }

/* ── Cuerpo de sección ── */
.pdv-body { padding: 1rem; }

/* ── Input de búsqueda ── */
.pdv-input-wrap { position: relative; }
.pdv-input-wrap svg {
    position: absolute; left: .75rem; top: 50%; transform: translateY(-50%);
    width: 1rem; height: 1rem; color: #9ca3af; pointer-events: none;
}
.pdv-input {
    width: 100%;
    border-radius: .75rem;
    border: 1px solid #e5e7eb;
    background: #f9fafb;
    color: #111827;
    font-size: .875rem;
    padding: .625rem 1rem .625rem 2.25rem;
    outline: none;
    transition: border-color .15s, box-shadow .15s;
    box-sizing: border-box;
}
html.dark .pdv-input {
    background: oklch(0.21 0.006 285.885); /* gray-900 */
    border-color: oklch(0.442 0.017 285.786); /* gray-600 */
    color: #f3f4f6;
}
.pdv-input:focus {
    border-color: #6d28d9;
    box-shadow: 0 0 0 3px rgb(109 40 217 / .15);
}
html.dark .pdv-input:focus {
    border-color: #7c3aed;
    box-shadow: 0 0 0 3px rgb(124 58 237 / .2);
}

/* ── Dropdown de clientes ── */
.pdv-dropdown {
    margin-top: .5rem;
    border: 1px solid #e5e7eb;
    border-radius: .75rem;
    overflow: hidden;
    box-shadow: 0 4px 12px rgb(0 0 0 / .1);
    max-height: 11rem;
    overflow-y: auto;
}
html.dark .pdv-dropdown { border-color: oklch(0.442 0.017 285.786); }
.pdv-dropdown-item {
    display: block; width: 100%; text-align: left;
    padding: .625rem 1rem;
    font-size: .875rem;
    color: #374151;
    border: none; background: none; cursor: pointer;
    border-bottom: 1px solid #f3f4f6;
    transition: background .1s;
}
.pdv-dropdown-item:last-child { border-bottom: none; }
.pdv-dropdown-item:hover { background: #f5f3ff; }
html.dark .pdv-dropdown-item { color: #d1d5db; border-bottom-color: oklch(0.37 0.013 285.805); }
html.dark .pdv-dropdown-item:hover { background: oklch(0.381 0.176 293.745 / .2); }

/* ── Cliente seleccionado ── */
.pdv-cliente-selected {
    display: flex; align-items: center; justify-content: space-between;
    background: #f5f3ff;
    border: 1px solid #ddd6fe;
    border-radius: .75rem;
    padding: .75rem 1rem;
}
html.dark .pdv-cliente-selected {
    background: oklch(0.381 0.176 293.745 / .2);
    border-color: oklch(0.381 0.176 293.745 / .5);
}
.pdv-cliente-name { font-size: .875rem; font-weight: 500; color: #5b21b6; }
html.dark .pdv-cliente-name { color: #c4b5fd; }
.pdv-clear-btn {
    width: 1.75rem; height: 1.75rem; border-radius: 9999px;
    border: none; background: none; cursor: pointer;
    color: #9ca3af; display: flex; align-items: center; justify-content: center;
    transition: background .1s, color .1s;
}
.pdv-clear-btn:hover { background: #fee2e2; color: #ef4444; }
html.dark .pdv-clear-btn:hover { background: oklch(0.505 0.213 27.518 / .3); }
.pdv-clear-btn svg { width: .875rem; height: .875rem; }

/* ── Grid de productos ── */
.pdv-productos-grid {
    margin-top: .75rem;
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: .625rem;
}
@media (min-width: 640px)  { .pdv-productos-grid { grid-template-columns: repeat(3, 1fr); } }
@media (min-width: 768px)  { .pdv-productos-grid { grid-template-columns: repeat(4, 1fr); } }

.pdv-producto-btn {
    text-align: left;
    padding: .75rem;
    border-radius: .75rem;
    border: 1px solid #e5e7eb;
    background: #ffffff;
    cursor: pointer;
    transition: border-color .15s, background .15s, box-shadow .15s, transform .1s;
}
html.dark .pdv-producto-btn {
    background: oklch(0.21 0.006 285.885 / .5);
    border-color: oklch(0.442 0.017 285.786);
}
.pdv-producto-btn:hover {
    border-color: #60a5fa;
    background: #eff6ff;
    box-shadow: 0 2px 8px rgb(0 0 0 / .1);
}
html.dark .pdv-producto-btn:hover {
    border-color: #3b82f6;
    background: oklch(0.488 0.243 264.376 / .2);
}
.pdv-producto-btn:active { transform: scale(.95); }
.pdv-producto-nombre {
    font-size: .75rem; font-weight: 600;
    color: #1f2937;
    white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
    margin-bottom: .375rem;
    display: block;
}
html.dark .pdv-producto-nombre { color: #f3f4f6; }
.pdv-producto-precio {
    font-size: 1rem; font-weight: 700;
    color: #2563eb;
    display: block;
}
html.dark .pdv-producto-precio { color: #60a5fa; }
.pdv-producto-stock {
    font-size: .625rem; font-weight: 600;
    margin-top: .375rem; display: flex; align-items: center; gap: .25rem;
}
.pdv-stock-ok  { color: #16a34a; }
html.dark .pdv-stock-ok { color: #4ade80; }
.pdv-stock-low { color: #d97706; }
.pdv-stock-out { color: #dc2626; }

/* ── Carrito vacío ── */
.pdv-empty {
    display: flex; flex-direction: column; align-items: center; justify-content: center;
    padding: 3.5rem 1rem; text-align: center;
}
.pdv-empty-icon {
    width: 4rem; height: 4rem; border-radius: 1rem;
    background: #f3f4f6;
    display: flex; align-items: center; justify-content: center;
    margin-bottom: .75rem;
}
html.dark .pdv-empty-icon { background: oklch(0.37 0.013 285.805); }
.pdv-empty-icon svg { width: 2rem; height: 2rem; color: #9ca3af; }
html.dark .pdv-empty-icon svg { color: #6b7280; }
.pdv-empty p { font-size: .875rem; color: #6b7280; }
html.dark .pdv-empty p { color: #9ca3af; }
.pdv-empty span { font-size: .75rem; color: #9ca3af; margin-top: .25rem; display: block; }

/* ── Tabla carrito ── */
.pdv-table { width: 100%; border-collapse: collapse; font-size: .875rem; }
.pdv-table thead { background: #f9fafb; }
html.dark .pdv-table thead { background: oklch(0.21 0.006 285.885 / .5); }
.pdv-table th {
    padding: .75rem 1rem;
    text-align: left; font-size: .6875rem; font-weight: 600;
    text-transform: uppercase; letter-spacing: .05em;
    color: #6b7280;
}
.pdv-table th.text-right { text-align: right; }
.pdv-table th.text-center { text-align: center; }
.pdv-table tr { border-bottom: 1px solid #f3f4f6; transition: background .1s; }
.pdv-table tr:last-child { border-bottom: none; }
.pdv-table tr:hover { background: #f9fafb; }
html.dark .pdv-table tr { border-bottom-color: oklch(0.37 0.013 285.805); }
html.dark .pdv-table tr:hover { background: oklch(0.37 0.013 285.805 / .3); }
.pdv-table td { padding: .75rem 1rem; color: #1f2937; }
html.dark .pdv-table td { color: #e5e7eb; }
.pdv-table td.text-right { text-align: right; color: #6b7280; font-variant-numeric: tabular-nums; }
html.dark .pdv-table td.text-right { color: #9ca3af; }
.pdv-table td.font-bold { font-weight: 700; color: #1f2937; }
html.dark .pdv-table td.font-bold { color: #f3f4f6; }
.pdv-table td.text-center { text-align: center; }

/* ── Controles de cantidad ── */
.pdv-qty {
    display: flex; align-items: center; justify-content: center; gap: .5rem;
}
.pdv-qty-btn {
    width: 1.75rem; height: 1.75rem; border-radius: .375rem;
    border: none; background: #f3f4f6; cursor: pointer;
    font-size: 1rem; font-weight: 700;
    display: flex; align-items: center; justify-content: center;
    transition: background .1s, color .1s;
    color: #374151;
}
html.dark .pdv-qty-btn { background: oklch(0.37 0.013 285.805); color: #d1d5db; }
.pdv-qty-btn.minus:hover { background: #fee2e2; color: #dc2626; }
.pdv-qty-btn.plus:hover  { background: #dcfce7; color: #16a34a; }
html.dark .pdv-qty-btn.minus:hover { background: oklch(0.505 0.213 27.518 / .3); }
html.dark .pdv-qty-btn.plus:hover  { background: oklch(0.527 0.154 150.069 / .3); }
.pdv-qty-val { width: 2rem; text-align: center; font-weight: 700; color: #1f2937; }
html.dark .pdv-qty-val { color: #f3f4f6; }
.pdv-del-btn {
    width: 1.75rem; height: 1.75rem; border-radius: .375rem;
    border: none; background: none; cursor: pointer;
    color: #d1d5db; display: flex; align-items: center; justify-content: center;
    opacity: 0; transition: opacity .1s, background .1s, color .1s;
}
.pdv-table tr:hover .pdv-del-btn { opacity: 1; }
.pdv-del-btn:hover { background: #fee2e2; color: #ef4444; }
.pdv-del-btn svg { width: .875rem; height: .875rem; }

/* ── Header carrito ── */
.pdv-section-header-between {
    display: flex; align-items: center; justify-content: space-between;
    padding: 1rem 1rem .75rem;
    border-bottom: 1px solid #f3f4f6;
}
html.dark .pdv-section-header-between { border-bottom-color: oklch(0.37 0.013 285.805); }
.pdv-badge {
    background: #ffedd5; color: #c2410c;
    font-size: .6875rem; font-weight: 700;
    padding: .125rem .5rem; border-radius: 9999px; margin-left: .375rem;
}
html.dark .pdv-badge {
    background: oklch(0.553 0.195 38.402 / .35);
    color: #fb923c;
}
.pdv-vaciar-btn {
    display: flex; align-items: center; gap: .375rem;
    border: none; background: none; cursor: pointer;
    font-size: .75rem; color: #9ca3af;
    padding: .375rem .625rem; border-radius: .5rem;
    transition: background .1s, color .1s;
}
.pdv-vaciar-btn:hover { background: #fee2e2; color: #ef4444; }
html.dark .pdv-vaciar-btn:hover { background: oklch(0.505 0.213 27.518 / .2); }
.pdv-vaciar-btn svg { width: .875rem; height: .875rem; }

/* ── Total destacado ── */
.pdv-total-box {
    border-radius: 1rem;
    background: linear-gradient(135deg, #2563eb, #4f46e5);
    padding: 1rem;
    color: white;
    box-shadow: 0 4px 14px rgb(37 99 235 / .35);
}
html.dark .pdv-total-box {
    background: linear-gradient(135deg, #1d4ed8, #3730a3);
}
.pdv-total-label { font-size: .6875rem; font-weight: 600; letter-spacing: .1em; text-transform: uppercase; color: #bfdbfe; margin-bottom: .25rem; }
.pdv-total-amount { font-size: 2.5rem; font-weight: 900; line-height: 1; letter-spacing: -.025em; font-variant-numeric: tabular-nums; }
.pdv-total-sub { font-size: .75rem; color: #93c5fd; margin-top: .5rem; }

/* ── Métodos de pago ── */
.pdv-metodos-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: .5rem; }
.pdv-metodo-btn {
    position: relative;
    display: flex; flex-direction: column; align-items: center; gap: .25rem;
    padding: .75rem .5rem;
    border-radius: .75rem;
    border: 2px solid #e5e7eb;
    background: #ffffff;
    cursor: pointer;
    font-size: .875rem; font-weight: 600;
    color: #6b7280;
    transition: border-color .15s, background .15s, box-shadow .15s;
}
html.dark .pdv-metodo-btn { border-color: oklch(0.442 0.017 285.786); background: oklch(0.21 0.006 285.885 / .5); color: #9ca3af; }
.pdv-metodo-btn:hover { border-color: #d1d5db; background: #f9fafb; }
html.dark .pdv-metodo-btn:hover { border-color: oklch(0.552 0.016 285.938); }
.pdv-metodo-btn.active { border-color: #3b82f6; background: #eff6ff; color: #1d4ed8; box-shadow: 0 1px 4px rgb(59 130 246 / .2); }
html.dark .pdv-metodo-btn.active { border-color: #3b82f6; background: oklch(0.488 0.243 264.376 / .25); color: #93c5fd; }
.pdv-metodo-btn .emoji { font-size: 1.25rem; line-height: 1; }
.pdv-metodo-dot {
    position: absolute; top: .375rem; right: .375rem;
    width: .5rem; height: .5rem; border-radius: 9999px;
    background: #3b82f6;
}

/* ── Botón cobrar ── */
.pdv-cobrar-btn {
    width: 100%; padding: 1rem;
    border-radius: .75rem; border: none; cursor: pointer;
    font-size: 1rem; font-weight: 700;
    background: #16a34a; color: white;
    box-shadow: 0 4px 14px rgb(22 163 74 / .35);
    display: flex; align-items: center; justify-content: center; gap: .5rem;
    transition: background .15s, box-shadow .15s, transform .1s;
}
.pdv-cobrar-btn:hover { background: #15803d; box-shadow: 0 6px 18px rgb(22 163 74 / .4); }
.pdv-cobrar-btn:active { transform: scale(.98); }
.pdv-cobrar-btn:disabled { background: #e5e7eb; color: #9ca3af; box-shadow: none; cursor: not-allowed; }
html.dark .pdv-cobrar-btn:disabled { background: oklch(0.37 0.013 285.805); color: #6b7280; }
.pdv-cobrar-btn svg { width: 1.25rem; height: 1.25rem; }
.pdv-cobrar-btn .spin { animation: spin .7s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }

/* ── Botón vaciar (en cobro) ── */
.pdv-vaciar2-btn {
    width: 100%; padding: .625rem; margin-top: .5rem;
    border-radius: .75rem; border: 1px solid #e5e7eb;
    background: none; cursor: pointer;
    font-size: .75rem; font-weight: 500;
    color: #9ca3af;
    display: flex; align-items: center; justify-content: center; gap: .375rem;
    transition: background .1s, color .1s, border-color .1s;
}
html.dark .pdv-vaciar2-btn { border-color: oklch(0.442 0.017 285.786); }
.pdv-vaciar2-btn:hover { background: #fee2e2; color: #ef4444; border-color: #fca5a5; }
html.dark .pdv-vaciar2-btn:hover { background: oklch(0.505 0.213 27.518 / .2); border-color: oklch(0.505 0.213 27.518 / .5); }
.pdv-vaciar2-btn svg { width: .875rem; height: .875rem; }

/* ── Ventas del día ── */
.pdv-venta-row {
    display: flex; align-items: center; justify-content: space-between;
    padding: .625rem 0;
    border-bottom: 1px solid #f3f4f6;
}
.pdv-venta-row:last-child { border-bottom: none; }
html.dark .pdv-venta-row { border-bottom-color: oklch(0.37 0.013 285.805); }
.pdv-venta-id {
    font-family: ui-monospace, monospace;
    font-size: .75rem; font-weight: 700;
    background: #f3f4f6; color: #6b7280;
    padding: .125rem .375rem; border-radius: .25rem;
}
html.dark .pdv-venta-id { background: oklch(0.37 0.013 285.805); color: #9ca3af; }
.pdv-venta-hora { font-size: .75rem; color: #9ca3af; margin-left: .5rem; }
.pdv-venta-amount { font-size: .875rem; font-weight: 700; color: #374151; font-variant-numeric: tabular-nums; }
html.dark .pdv-venta-amount { color: #e5e7eb; }
.pdv-print-btn {
    width: 1.75rem; height: 1.75rem; border-radius: .5rem;
    background: #f3f4f6; color: #9ca3af;
    display: flex; align-items: center; justify-content: center;
    text-decoration: none;
    transition: background .1s, color .1s;
    margin-left: .5rem;
}
.pdv-print-btn:hover { background: #dbeafe; color: #2563eb; }
html.dark .pdv-print-btn { background: oklch(0.37 0.013 285.805); }
html.dark .pdv-print-btn:hover { background: oklch(0.488 0.243 264.376 / .3); color: #60a5fa; }
.pdv-print-btn svg { width: .875rem; height: .875rem; }
.pdv-total-dia {
    display: flex; align-items: center; justify-content: space-between;
    margin-top: .75rem; padding-top: .75rem;
    border-top: 1px solid #f3f4f6;
}
html.dark .pdv-total-dia { border-top-color: oklch(0.37 0.013 285.805); }
.pdv-total-dia span { font-size: .75rem; font-weight: 600; text-transform: uppercase; letter-spacing: .05em; color: #9ca3af; }
.pdv-total-dia strong { font-size: 1rem; font-weight: 800; color: #16a34a; font-variant-numeric: tabular-nums; }
html.dark .pdv-total-dia strong { color: #4ade80; }
.pdv-empty-dia { text-align: center; padding: 2rem 0; }
.pdv-empty-dia svg { width: 2.25rem; height: 2.25rem; color: #d1d5db; margin: 0 auto .5rem; display: block; }
html.dark .pdv-empty-dia svg { color: oklch(0.442 0.017 285.786); }
.pdv-empty-dia p { font-size: .875rem; color: #9ca3af; }
.pdv-no-results { font-size: .75rem; color: #9ca3af; padding: .5rem 0; }
.pdv-metodos-label { font-size: .6875rem; font-weight: 600; text-transform: uppercase; letter-spacing: .05em; color: #9ca3af; margin-bottom: .625rem; }
</style>

<div class="pdv-grid">

    {{-- ═══════════════════════════════ --}}
    {{-- IZQUIERDA: Búsqueda + Carrito  --}}
    {{-- ═══════════════════════════════ --}}
    <div class="pdv-col-left">

        {{-- CLIENTE --}}
        <div class="pdv-card">
            <div class="pdv-section-header">
                <div class="pdv-section-icon pdv-icon-violet">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
                </div>
                <span class="pdv-section-title">Cliente</span>
                <span class="pdv-section-sub">— opcional</span>
            </div>
            <div class="pdv-body">
                @if($clienteId)
                    <div class="pdv-cliente-selected">
                        <span class="pdv-cliente-name">{{ $this->getClienteSeleccionado() }}</span>
                        <button wire:click="limpiarCliente" class="pdv-clear-btn" title="Quitar cliente">
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M6 18L18 6M6 6l12 12"/></svg>
                        </button>
                    </div>
                @else
                    <div class="pdv-input-wrap">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
                        <input wire:model.live.debounce.250ms="buscarCliente" type="text" placeholder="Buscar por nombre o DNI..." autocomplete="off" class="pdv-input">
                    </div>
                    @php $clientes = $this->getClientesFiltrados(); @endphp
                    @if(count($clientes))
                        <div class="pdv-dropdown" style="margin-top:.5rem">
                            @foreach($clientes as $c)
                                <button wire:click="seleccionarCliente({{ $c['id'] }})" class="pdv-dropdown-item">{{ $c['label'] }}</button>
                            @endforeach
                        </div>
                    @elseif(strlen($buscarCliente) >= 2)
                        <p class="pdv-no-results">Sin resultados para "{{ $buscarCliente }}"</p>
                    @endif
                @endif
            </div>
        </div>

        {{-- BUSCAR PRODUCTO --}}
        <div class="pdv-card">
            <div class="pdv-section-header">
                <div class="pdv-section-icon pdv-icon-blue">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
                </div>
                <span class="pdv-section-title">Buscar producto</span>
            </div>
            <div class="pdv-body">
                <div class="pdv-input-wrap">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
                    <input wire:model.live.debounce.250ms="buscarProducto" type="text" placeholder="Nombre o código del producto..." autocomplete="off" class="pdv-input">
                </div>
                @php $productos = $this->getProductosDisponibles(); @endphp
                @if(count($productos))
                    <div class="pdv-productos-grid">
                        @foreach($productos as $p)
                            <button wire:click="agregarProducto({{ $p['id'] }})" class="pdv-producto-btn">
                                <span class="pdv-producto-nombre">{{ $p['nombre'] }}</span>
                                <span class="pdv-producto-precio">S/ {{ number_format($p['precio_venta'], 2) }}</span>
                                <div class="pdv-producto-stock">
                                    <span style="color:#9ca3af;font-size:.6rem">Stock:</span>
                                    <span class="{{ $p['stock'] > 5 ? 'pdv-stock-ok' : ($p['stock'] > 0 ? 'pdv-stock-low' : 'pdv-stock-out') }}">{{ $p['stock'] }}</span>
                                </div>
                            </button>
                        @endforeach
                    </div>
                @elseif(strlen($buscarProducto) >= 2)
                    <p class="pdv-no-results" style="margin-top:.75rem">Sin resultados para "{{ $buscarProducto }}"</p>
                @endif
            </div>
        </div>

        {{-- CARRITO --}}
        <div class="pdv-card">
            <div class="pdv-section-header-between">
                <div style="display:flex;align-items:center;gap:.625rem">
                    <div class="pdv-section-icon pdv-icon-orange">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
                    </div>
                    <span class="pdv-section-title">Carrito</span>
                    @if(count($carrito) > 0)
                        <span class="pdv-badge">{{ count($carrito) }}</span>
                    @endif
                </div>
                @if(count($carrito) > 0)
                    <button wire:click="limpiarCarrito" class="pdv-vaciar-btn">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                        Vaciar
                    </button>
                @endif
            </div>

            @if(empty($carrito))
                <div class="pdv-empty">
                    <div class="pdv-empty-icon">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
                    </div>
                    <p>El carrito está vacío</p>
                    <span>Busca un producto arriba para agregar</span>
                </div>
            @else
                <div style="overflow-x:auto">
                    <table class="pdv-table">
                        <thead>
                            <tr>
                                <th>Producto</th>
                                <th class="text-center" style="width:9rem">Cantidad</th>
                                <th class="text-right">Precio</th>
                                <th class="text-right">Subtotal</th>
                                <th style="width:2.5rem"></th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($carrito as $index => $item)
                                <tr>
                                    <td>{{ $item['nombre'] }}</td>
                                    <td class="text-center">
                                        <div class="pdv-qty">
                                            <button wire:click="actualizarCantidad({{ $index }}, {{ $item['cantidad'] - 1 }})" class="pdv-qty-btn minus">−</button>
                                            <span class="pdv-qty-val">{{ $item['cantidad'] }}</span>
                                            <button wire:click="actualizarCantidad({{ $index }}, {{ $item['cantidad'] + 1 }})" class="pdv-qty-btn plus">+</button>
                                        </div>
                                    </td>
                                    <td class="text-right">S/ {{ number_format($item['precio'], 2) }}</td>
                                    <td class="text-right font-bold">S/ {{ number_format($item['subtotal'], 2) }}</td>
                                    <td class="text-center">
                                        <button wire:click="eliminarItem({{ $index }})" class="pdv-del-btn" title="Eliminar">
                                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M6 18L18 6M6 6l12 12"/></svg>
                                        </button>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            @endif
        </div>
    </div>

    {{-- ═══════════════════ --}}
    {{-- DERECHA: Cobro     --}}
    {{-- ═══════════════════ --}}
    <div class="pdv-col-right">

        {{-- COBRO --}}
        <div class="pdv-card">
            <div class="pdv-section-header">
                <div class="pdv-section-icon pdv-icon-green">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
                </div>
                <span class="pdv-section-title">Cobro</span>
            </div>
            <div class="pdv-body" style="display:flex;flex-direction:column;gap:1rem">

                {{-- Total --}}
                <div class="pdv-total-box">
                    <p class="pdv-total-label">Total a cobrar</p>
                    <p class="pdv-total-amount">S/ {{ number_format($total, 2) }}</p>
                    @if(count($carrito) > 0)
                        <p class="pdv-total-sub">{{ count($carrito) }} {{ count($carrito) === 1 ? 'producto' : 'productos' }} · {{ ucfirst($metodoPago) }}</p>
                    @else
                        <p class="pdv-total-sub">Sin productos en el carrito</p>
                    @endif
                </div>

                {{-- Métodos de pago --}}
                <div>
                    <p class="pdv-metodos-label">Método de pago</p>
                    <div class="pdv-metodos-grid">
                        @foreach(['efectivo' => '💵 Efectivo', 'yape' => '📱 Yape', 'plin' => '💜 Plin', 'transferencia' => '🏦 Transf.'] as $valor => $label)
                            <button wire:click="$set('metodoPago', '{{ $valor }}')"
                                class="pdv-metodo-btn {{ $metodoPago === $valor ? 'active' : '' }}">
                                <span class="emoji">{{ explode(' ', $label)[0] }}</span>
                                <span>{{ trim(substr($label, mb_strlen(explode(' ', $label)[0]))) }}</span>
                                @if($metodoPago === $valor)
                                    <span class="pdv-metodo-dot"></span>
                                @endif
                            </button>
                        @endforeach
                    </div>
                </div>

                {{-- Botón cobrar --}}
                @if(empty($carrito))
                    <button disabled class="pdv-cobrar-btn">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4"/></svg>
                        Agrega productos para cobrar
                    </button>
                @else
                    <button wire:click="finalizarVenta" wire:loading.attr="disabled" wire:target="finalizarVenta" class="pdv-cobrar-btn">
                        <span wire:loading.remove wire:target="finalizarVenta" style="display:flex;align-items:center;gap:.5rem">
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" style="width:1.25rem;height:1.25rem"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M5 13l4 4L19 7"/></svg>
                            Cobrar S/ {{ number_format($total, 2) }}
                        </span>
                        <span wire:loading wire:target="finalizarVenta" style="display:flex;align-items:center;gap:.5rem">
                            <svg class="spin" fill="none" viewBox="0 0 24 24" style="width:1rem;height:1rem"><circle style="opacity:.25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"/><path style="opacity:.75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/></svg>
                            Procesando...
                        </span>
                    </button>
                    <button wire:click="limpiarCarrito" class="pdv-vaciar2-btn">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                        Vaciar carrito
                    </button>
                @endif
            </div>
        </div>

        {{-- VENTAS DEL DÍA --}}
        <div class="pdv-card">
            <div class="pdv-section-header">
                <div class="pdv-section-icon pdv-icon-teal">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>
                </div>
                <span class="pdv-section-title">Ventas de hoy</span>
            </div>
            @php
                $ventasHoy = \App\Models\Venta::whereDate('created_at', today())
                    ->where('estado', 'completada')->latest()->take(8)->get();
            @endphp
            <div class="pdv-body">
                @forelse($ventasHoy as $v)
                    <div class="pdv-venta-row">
                        <div style="display:flex;align-items:center">
                            <span class="pdv-venta-id">#{{ str_pad($v->id, 4, '0', STR_PAD_LEFT) }}</span>
                            <span class="pdv-venta-hora">{{ $v->created_at->format('H:i') }}</span>
                        </div>
                        <div style="display:flex;align-items:center">
                            <span class="pdv-venta-amount">S/ {{ number_format($v->total, 2) }}</span>
                            <a href="{{ route('ticket.venta', $v) }}" target="_blank" class="pdv-print-btn" title="Imprimir ticket">
                                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"/></svg>
                            </a>
                        </div>
                    </div>
                @empty
                    <div class="pdv-empty-dia">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>
                        <p>Sin ventas registradas hoy</p>
                    </div>
                @endforelse
                @if($ventasHoy->isNotEmpty())
                    <div class="pdv-total-dia">
                        <span>Total del día</span>
                        <strong>S/ {{ number_format($ventasHoy->sum('total'), 2) }}</strong>
                    </div>
                @endif
            </div>
        </div>
    </div>
</div>

<script>
    {{-- Listener open-ticket manejado globalmente en AdminPanelProvider --}}
</script>
</x-filament-panels::page>

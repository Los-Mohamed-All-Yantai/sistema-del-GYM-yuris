<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Nota de Pedido - Venta {{ str_pad($venta->id, 6, '0', STR_PAD_LEFT) }}</title>
    <style>
        * { font-family: 'Lucida Console', Monaco, monospace; font-size: 11px; line-height: 1.3; margin: 0; padding: 0; }
        body { width: 72mm; margin: 0 auto; padding: 5px; color: #000; background-color: #fff; }
        .ticket { width: 100%; }
        .center { text-align: center; }
        .bold { font-weight: bold; }
        .divider { border-top: 1px dashed #000; margin: 5px 0; height: 1px; }
        .logo { width: 65%; height: auto; margin: 0 auto 10px; display: block; filter: grayscale(100%); }
        table { width: 100%; border-collapse: collapse; }
        th { font-weight: bold; text-align: left; border-bottom: 1px solid #000; padding-bottom: 2px; font-size: 10px; }
        td { padding: 1px 0; font-size: 10px; vertical-align: top; }
        .text-right { text-align: right; }
        .text-center { text-align: center; }
        .col-desc { width: 42%; }
        .col-cant { width: 10%; text-align: center; }
        .col-pu   { width: 22%; text-align: right; }
        .col-tot  { width: 26%; text-align: right; }
        .footer-extra { font-size: 9px; margin-top: 10px; }
        @media print {
            .no-print { display: none; }
            @page { margin: 0; size: 72mm auto; }
        }
    </style>
</head>
<body onload="window.print();">
    <div class="ticket">

        <img src="{{ asset('img/LogoGym.jpg') }}" class="logo" alt="YURI'S GYM">

        <p class="center bold" style="font-size: 14px;">YURI'S GYM HILARIO MENDIVIL</p>
        <p class="center">Cl. Las Palmeras con Chachacomo</p>
        <p class="center">San Sebastián, Cusco</p>

        <div class="divider"></div>

        <p class="center bold">NOTA DE PEDIDO</p>
        <p class="center">Nro: {{ str_pad($venta->id, 6, '0', STR_PAD_LEFT) }}</p>

        <p>FECHA: {{ $venta->created_at->format('d/m/Y') }} | {{ $venta->created_at->format('H:i') }}</p>
        <p>PAGO : {{ strtoupper($venta->metodo_pago) }}</p>

        <div class="divider"></div>

        <p style="word-break: break-word;">CLIENTE: {{ $nombreCliente }}</p>

        <div class="divider"></div>

        <table>
            <thead>
                <tr>
                    <th class="col-desc">DESCRIPCION</th>
                    <th class="col-cant">CANT</th>
                    <th class="col-pu">P.UNIT</th>
                    <th class="col-tot">TOTAL</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($venta->detalles as $detalle)
                <tr>
                    <td class="col-desc">{{ strtoupper($detalle->producto->nombre) }}</td>
                    <td class="col-cant">{{ $detalle->cantidad }}</td>
                    <td class="col-pu">{{ number_format($detalle->precio_unitario, 2) }}</td>
                    <td class="col-tot">{{ number_format($detalle->subtotal, 2) }}</td>
                </tr>
                @endforeach
            </tbody>
        </table>

        <div class="divider"></div>

        <table>
            <tr style="font-size: 12px;">
                <td class="bold">TOTAL A PAGAR:</td>
                <td class="bold text-right">S/ {{ number_format($venta->total, 2) }}</td>
            </tr>
        </table>

        <p style="margin-top: 5px; font-size: 9px;">{{ $montoLetras }}</p>

        <div class="divider"></div>

        <p class="center bold">¡GRACIAS POR SU COMPRA!</p>

        <div class="center" style="margin: 10px 0;">
            <img src="https://api.qrserver.com/v1/create-qr-code/?size=100x100&data=VENTA-{{ str_pad($venta->id, 6, '0', STR_PAD_LEFT) }}-S/{{ number_format($venta->total, 2) }}"
                 style="width: 70px;" alt="QR Venta">
        </div>

        <div class="footer-extra center">
            Yuri's Gym - Cusco
        </div>

    </div>

    <script>
        window.onafterprint = function () {
            setTimeout(function () { window.close(); }, 500);
        };
    </script>
</body>
</html>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Renovación - Yuri's Gym</title>
    <style>
        * { font-family: 'Lucida Console', Monaco, monospace; font-size: 11px; line-height: 1.3; margin: 0; padding: 0; }
        body { width: 72mm; margin: 0 auto; padding: 5px; color: #000; background-color: #fff; }
        .ticket { width: 100%; }
        .center { text-align: center; }
        .bold { font-weight: bold; }
        .divider { border-top: 1px dashed #000; margin: 5px 0; height: 1px; }
        .logo { width: 65%; height: auto; margin: 0 auto 10px; display: block; filter: grayscale(100%); }
        table { width: 100%; border-collapse: collapse; }
        .text-right { text-align: right; }
        .footer-extra { font-size: 9px; margin-top: 10px; }
        @media print { .no-print { display: none; } }
    </style>
</head>
<body onload="window.print();">
    <div class="ticket">

        <img src="{{ asset('img/LogoGym.jpg') }}" class="logo" alt="YURI'S GYM">

        <p class="center bold" style="font-size: 14px;">YURI'S GYM HILARIO MENDIVIL</p>
        <p class="center">San Sebastián, Cusco</p>

        <div class="divider"></div>

        <p class="center bold">NOTA DE PEDIDO</p>
        <div style="text-align: center; margin: 6px 0;">
            <span style="border: 2px solid black; padding: 4px 14px; font-weight: bold; display: inline-block;">
                RENOVACIÓN
            </span>
        </div>
        <p class="center">Nro: {{ str_pad($membresia->id, 6, '0', STR_PAD_LEFT) }}</p>

        <p>FECHA: {{ now()->format('d/m/Y') }} | {{ now()->format('H:i') }}</p>
        <p>PAGO : {{ strtoupper($membresia->metodo_pago) }}</p>

        <div class="divider"></div>

        <p>CLIENTE: {{ strtoupper($membresia->cliente->nombres . ' ' . $membresia->cliente->apellido_paterno) }}</p>
        <p>DNI    : {{ $membresia->cliente->dni }}</p>

        <div class="divider"></div>

        <table>
            <tr>
                <td class="bold">DESCRIPCION</td>
                <td class="bold text-right">TOTAL</td>
            </tr>
            <tr>
                <td>RENOV. {{ strtoupper($membresia->plan->nombre) }}</td>
                <td class="text-right">{{ number_format($membresia->precio_pagado, 2) }}</td>
            </tr>
        </table>

        <div class="divider"></div>

        <table>
            <tr style="font-size: 12px;">
                <td class="bold">TOTAL A PAGAR:</td>
                <td class="bold text-right">S/ {{ number_format($membresia->precio_pagado, 2) }}</td>
            </tr>
        </table>

        <p style="margin-top: 5px; font-size: 9px;">{{ $montoLetras }}</p>

        <div class="divider"></div>

        <p class="center">NUEVA VIGENCIA:</p>
        <p class="center">Desde: {{ $membresia->fecha_inicio->format('d/m/Y') }}</p>
        <p class="center bold">Hasta: {{ $membresia->fecha_fin->format('d/m/Y') }}</p>
        <p class="center"><u>¡CLASES NO RECUPERABLES!</u></p>

        <div class="divider"></div>

        <p class="center bold">¡TRANSFORMA TU CUERPO!</p>

        <div class="center" style="margin: 10px 0;">
            <img src="https://api.qrserver.com/v1/create-qr-code/?size=100x100&data=SOCIO-{{ $membresia->cliente->dni }}"
                 style="width: 70px;" alt="QR">
        </div>

        <div class="footer-extra center">
            Yuri's Gym - Cusco
        </div>

    </div>

    <script>
        window.onafterprint = function () {
            setTimeout(function () { window.close(); }, 500);
        };
    </script>
</body>
</html>

@extends('boletas.layout')
@section('titulo', 'Ticket de Venta')

@section('contenido')
<div class="center bold" style="font-size:13px; margin-bottom:2mm;">TICKET DE VENTA #{{ str_pad($venta->id, 5, '0', STR_PAD_LEFT) }}</div>

<div class="separator"></div>

<div><strong>Cliente:</strong> {{ $venta->cliente?->nombre_completo ?? 'Cliente general' }}</div>
<div><strong>Pago:</strong> {{ ucfirst($venta->metodo_pago) }}</div>

<div class="separator"></div>

<table>
    <thead>
        <tr>
            <th style="text-align:left;">Producto</th>
            <th style="text-align:right;">Cant</th>
            <th style="text-align:right;">Precio</th>
            <th style="text-align:right;">Subtotal</th>
        </tr>
    </thead>
    <tbody>
        <tr><td colspan="4"><div class="separator"></div></td></tr>
        @foreach($venta->detalles as $detalle)
        <tr>
            <td>{{ $detalle->producto->nombre }}</td>
            <td class="right">{{ $detalle->cantidad }}</td>
            <td class="right">{{ number_format($detalle->precio_unitario, 2) }}</td>
            <td class="right">{{ number_format($detalle->subtotal, 2) }}</td>
        </tr>
        @endforeach
    </tbody>
</table>

<div class="separator-solid"></div>
<table>
    @if($venta->descuento > 0)
    <tr>
        <td>Descuento:</td>
        <td class="right">-S/ {{ number_format($venta->descuento, 2) }}</td>
    </tr>
    @endif
    <tr class="total-row">
        <td>TOTAL</td>
        <td class="right">S/ {{ number_format($venta->total, 2) }}</td>
    </tr>
</table>
@endsection

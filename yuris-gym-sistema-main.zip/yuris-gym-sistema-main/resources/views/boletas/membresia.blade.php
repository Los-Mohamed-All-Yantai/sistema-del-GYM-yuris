@extends('boletas.layout')
@section('titulo', 'Boleta de Membresía')

@section('contenido')
<div class="center bold" style="font-size:13px; margin-bottom:2mm;">
    {{ $membresia->wasRecentlyCreated || $membresia->created_at->diffInMinutes() < 5 ? 'NUEVA INSCRIPCIÓN' : 'RENOVACIÓN DE MEMBRESÍA' }}
</div>

<div class="separator"></div>

<div><strong>DNI:</strong> {{ $cliente->dni }}</div>
<div><strong>Cliente:</strong> {{ $cliente->nombre_completo }}</div>
<div><strong>Teléfono:</strong> {{ $cliente->telefono ?? 'N/A' }}</div>

<div class="separator"></div>

<table>
    <tr>
        <td>Plan:</td>
        <td class="right bold">{{ $membresia->plan->nombre }}</td>
    </tr>
    <tr>
        <td>Inicio:</td>
        <td class="right">{{ $membresia->fecha_inicio->format('d/m/Y') }}</td>
    </tr>
    <tr>
        <td>Vencimiento:</td>
        <td class="right bold">{{ $membresia->fecha_fin->format('d/m/Y') }}</td>
    </tr>
    <tr>
        <td>Duración:</td>
        <td class="right">{{ $membresia->plan->duracion_dias }} días</td>
    </tr>
    <tr>
        <td>Pago:</td>
        <td class="right">{{ ucfirst($membresia->metodo_pago) }}</td>
    </tr>
</table>

<div class="separator-solid"></div>
<table>
    <tr class="total-row">
        <td>TOTAL PAGADO</td>
        <td class="right">S/ {{ number_format($membresia->precio_pagado, 2) }}</td>
    </tr>
</table>

@if($cliente->codigo_qr)
<div class="separator"></div>
<div class="center">
    <div class="subtitle" style="margin-bottom:2mm;">Tu QR de acceso:</div>
    <img src="https://api.qrserver.com/v1/create-qr-code/?size=100x100&data={{ urlencode($cliente->codigo_qr) }}" alt="QR" style="width:25mm; height:25mm;">
    <div class="subtitle" style="margin-top:1mm; font-size:8px;">Muéstralo en la entrada</div>
</div>
@endif
@endsection

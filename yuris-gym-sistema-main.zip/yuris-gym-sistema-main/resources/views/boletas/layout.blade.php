<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('titulo', 'Boleta') - Yuri's Gym</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Courier New', monospace; font-size: 12px; color: #000; background: #fff; }
        .ticket { width: 80mm; max-width: 80mm; margin: 0 auto; padding: 4mm; }
        .center { text-align: center; }
        .right  { text-align: right; }
        .bold   { font-weight: bold; }
        .separator { border-top: 1px dashed #000; margin: 3mm 0; }
        .separator-solid { border-top: 2px solid #000; margin: 3mm 0; }
        .logo { font-size: 18px; font-weight: bold; letter-spacing: 2px; }
        .subtitle { font-size: 10px; color: #444; }
        table { width: 100%; border-collapse: collapse; }
        td, th { padding: 1mm 0; font-size: 11px; }
        .total-row td { font-size: 14px; font-weight: bold; padding-top: 2mm; }
        .badge { display: inline-block; background: #000; color: #fff; padding: 1mm 3mm; font-size: 10px; }
        @media print {
            body { margin: 0; }
            .no-print { display: none; }
            @page { margin: 0; size: 80mm auto; }
        }
    </style>
</head>
<body>
    <div class="ticket">
        {{-- Header --}}
        <div class="center">
            <div class="logo">{{ config('gym.nombre', "Yuri's Gym") }}</div>
            <div class="subtitle">Sistema de Gestión de Gimnasio</div>
            <div class="separator"></div>
            <div>{{ config('gym.nombre', 'Tu Gimnasio') }}</div>
            <div class="subtitle">{{ config('gym.direccion', '') }}</div>
            <div class="subtitle">{{ config('gym.telefono', '') }}</div>
        </div>
        <div class="separator-solid"></div>

        @yield('contenido')

        <div class="separator"></div>
        <div class="center subtitle">
            <div>Generado: {{ now()->format('d/m/Y H:i:s') }}</div>
            <div>Atendido por: {{ auth()->user()?->name ?? 'Sistema' }}</div>
            <div class="separator"></div>
            <div class="bold">¡Gracias por preferirnos!</div>
        </div>
    </div>

    <div class="no-print" style="text-align:center; margin-top:10px;">
        <button onclick="window.print()" style="padding:8px 20px; background:#2563eb; color:white; border:none; border-radius:6px; cursor:pointer; font-size:14px;">
            🖨️ Imprimir
        </button>
        <button onclick="window.close()" style="padding:8px 20px; background:#6b7280; color:white; border:none; border-radius:6px; cursor:pointer; font-size:14px; margin-left:8px;">
            Cerrar
        </button>
    </div>

    <script>
        window.addEventListener('load', () => window.print());
    </script>
</body>
</html>

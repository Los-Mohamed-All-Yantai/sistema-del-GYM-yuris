<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>QR - {{ $cliente->nombre_completo }}</title>
    <style>
        body { font-family: Arial, sans-serif; text-align: center; padding: 40px; background: #f8fafc; }
        .card { background: white; border-radius: 16px; padding: 32px; max-width: 300px; margin: 0 auto; box-shadow: 0 4px 20px rgba(0,0,0,.1); }
        h2 { color: #1e40af; margin-bottom: 4px; font-size: 20px; }
        p { color: #64748b; font-size: 14px; margin: 4px 0; }
        img { margin: 20px 0; border: 2px solid #e2e8f0; border-radius: 8px; padding: 8px; }
        .badge { background: #1e40af; color: white; padding: 6px 16px; border-radius: 999px; font-size: 12px; font-weight: bold; }
        @media print { body { background: white; } .no-print { display: none; } }
    </style>
</head>
<body>
    <div class="card">
        <div class="badge">CARNET DIGITAL</div>
        <h2>{{ $cliente->nombres }}</h2>
        <p>{{ $cliente->apellido_paterno }} {{ $cliente->apellido_materno }}</p>
        <p><strong>DNI:</strong> {{ $cliente->dni }}</p>

        <img
            src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data={{ urlencode($cliente->codigo_qr) }}"
            alt="QR de acceso"
            width="200"
        >

        @if($cliente->membresiaActiva)
            <p><strong>Plan:</strong> {{ $cliente->membresiaActiva->plan->nombre }}</p>
            <p><strong>Vence:</strong> {{ $cliente->membresiaActiva->fecha_fin->format('d/m/Y') }}</p>
            <p style="color: {{ $cliente->dias_restantes > 5 ? '#16a34a' : ($cliente->dias_restantes > 0 ? '#d97706' : '#dc2626') }}; font-weight:bold;">
                {{ $cliente->dias_restantes > 0 ? $cliente->dias_restantes . ' días restantes' : 'MEMBRESÍA VENCIDA' }}
            </p>
        @else
            <p style="color: #dc2626; font-weight:bold;">Sin membresía activa</p>
        @endif

        <div class="no-print" style="margin-top: 20px;">
            <button onclick="window.print()" style="padding:8px 20px; background:#1e40af; color:white; border:none; border-radius:8px; cursor:pointer;">🖨️ Imprimir</button>
        </div>
    </div>
</body>
</html>

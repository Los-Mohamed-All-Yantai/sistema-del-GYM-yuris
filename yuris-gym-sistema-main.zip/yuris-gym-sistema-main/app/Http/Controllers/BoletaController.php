<?php

namespace App\Http\Controllers;

use App\Models\Cliente;
use App\Models\Membresia;
use App\Models\Venta;
use Illuminate\Http\Request;

class BoletaController extends Controller
{
    public function membresia(Membresia $membresia)
    {
        $membresia->load('cliente', 'plan');
        return view('boletas.membresia', [
            'membresia' => $membresia,
            'cliente'   => $membresia->cliente,
        ]);
    }

    public function venta(Venta $venta)
    {
        $venta->load('cliente', 'detalles.producto', 'vendidoPor');
        return view('boletas.venta', compact('venta'));
    }

    public function qrCliente(Cliente $cliente)
    {
        if (!$cliente->codigo_qr) {
            $cliente->update(['codigo_qr' => \Illuminate\Support\Str::uuid()]);
        }
        return view('boletas.qr-cliente', compact('cliente'));
    }
}

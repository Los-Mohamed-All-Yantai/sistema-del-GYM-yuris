<?php

namespace App\Http\Controllers;

use App\Models\Membresia;
use App\Models\Venta;

class TicketController extends Controller
{
    public function venta(Venta $venta): \Illuminate\View\View
    {
        $venta->load('cliente', 'detalles.producto');

        $nombreCliente = $venta->cliente
            ? strtoupper($venta->cliente->nombres . ' ' . $venta->cliente->apellido_paterno)
            : 'CLIENTE GENÉRICO / AMBULANTE';

        return view('tickets.venta', [
            'venta'         => $venta,
            'nombreCliente' => $nombreCliente,
            'montoLetras'   => $this->numeroALetras((float) $venta->total),
        ]);
    }

    public function inscripcion(Membresia $membresia): \Illuminate\View\View
    {
        $membresia->load('cliente', 'plan');

        return view('tickets.inscripcion', [
            'membresia'   => $membresia,
            'montoLetras' => $this->numeroALetras((float) $membresia->precio_pagado),
        ]);
    }

    public function renovacion(Membresia $membresia): \Illuminate\View\View
    {
        $membresia->load('cliente', 'plan');

        return view('tickets.renovacion', [
            'membresia'   => $membresia,
            'montoLetras' => $this->numeroALetras((float) $membresia->precio_pagado),
        ]);
    }

    private function numeroALetras(float $monto): string
    {
        $entero   = (int) floor($monto);
        $centavos = (int) round(($monto - $entero) * 100);

        return strtoupper($this->convertirEntero($entero))
            . ' CON ' . str_pad($centavos, 2, '0', STR_PAD_LEFT) . '/100 SOLES';
    }

    private function convertirEntero(int $n): string
    {
        if ($n === 0)   return 'cero';
        if ($n === 100) return 'cien';

        $u = [
            '', 'uno', 'dos', 'tres', 'cuatro', 'cinco', 'seis', 'siete', 'ocho', 'nueve',
            'diez', 'once', 'doce', 'trece', 'catorce', 'quince', 'dieciséis',
            'diecisiete', 'dieciocho', 'diecinueve',
        ];
        $d = ['', '', 'veinte', 'treinta', 'cuarenta', 'cincuenta', 'sesenta', 'setenta', 'ochenta', 'noventa'];
        $c = [
            '', 'ciento', 'doscientos', 'trescientos', 'cuatrocientos', 'quinientos',
            'seiscientos', 'setecientos', 'ochocientos', 'novecientos',
        ];

        if ($n < 20)  return $u[$n];
        if ($n < 30)  return $n === 20 ? 'veinte' : 'veinti' . $u[$n - 20];
        if ($n < 100) {
            $resto = $n % 10;
            return $resto ? $d[intdiv($n, 10)] . ' y ' . $u[$resto] : $d[intdiv($n, 10)];
        }
        if ($n < 1000) {
            $resto = $n % 100;
            return $resto
                ? $c[intdiv($n, 100)] . ' ' . $this->convertirEntero($resto)
                : $c[intdiv($n, 100)];
        }
        if ($n < 2000) {
            $resto = $n % 1000;
            return $resto ? 'mil ' . $this->convertirEntero($resto) : 'mil';
        }

        $miles = intdiv($n, 1000);
        $resto  = $n % 1000;
        $prefix = $this->convertirEntero($miles) . ' mil';

        return $resto ? $prefix . ' ' . $this->convertirEntero($resto) : $prefix;
    }
}

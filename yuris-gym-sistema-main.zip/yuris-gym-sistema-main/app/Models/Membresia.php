<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Membresia extends Model
{
    protected $fillable = [
        'cliente_id', 'plan_id', 'fecha_inicio', 'fecha_fin',
        'precio_pagado', 'metodo_pago', 'voucher', 'estado', 'observaciones', 'user_id',
    ];

    protected $casts = [
        'fecha_inicio' => 'date',
        'fecha_fin' => 'date',
        'precio_pagado' => 'decimal:2',
    ];

    public function cliente(): BelongsTo
    {
        return $this->belongsTo(Cliente::class);
    }

    public function plan(): BelongsTo
    {
        return $this->belongsTo(Plan::class);
    }

    public function registradoPor(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function getDiasRestantesAttribute(): int
    {
        return max(0, (int) now()->diffInDays($this->fecha_fin, false));
    }

    public function estaVigente(): bool
    {
        return $this->estado === 'activa' && $this->fecha_fin >= now()->toDateString();
    }

    protected static function booted(): void
    {
        static::saving(function (Membresia $m) {
            if ($m->fecha_fin < now()->toDateString()) {
                $m->estado = 'vencida';
            }
        });
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Asistencia extends Model
{
    protected $fillable = ['cliente_id', 'membresia_id', 'entrada_at', 'salida_at', 'tipo_acceso'];

    protected $casts = [
        'entrada_at' => 'datetime',
        'salida_at' => 'datetime',
    ];

    public function cliente(): BelongsTo
    {
        return $this->belongsTo(Cliente::class);
    }

    public function membresia(): BelongsTo
    {
        return $this->belongsTo(Membresia::class);
    }

    public function getDuracionAttribute(): ?string
    {
        if (!$this->salida_at) return null;
        $minutos = $this->entrada_at->diffInMinutes($this->salida_at);
        return "{$minutos} min";
    }
}

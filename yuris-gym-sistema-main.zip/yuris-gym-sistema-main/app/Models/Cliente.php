<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Cliente extends Model
{
    protected $fillable = [
        'dni', 'nombres', 'apellido_paterno', 'apellido_materno',
        'telefono', 'email', 'fecha_nacimiento', 'foto', 'codigo_qr', 'activo',
    ];

    protected $casts = [
        'activo' => 'boolean',
        'fecha_nacimiento' => 'date',
    ];

    public function membresias(): HasMany
    {
        return $this->hasMany(Membresia::class);
    }

    public function membresiaActiva(): HasOne
    {
        return $this->hasOne(Membresia::class)
            ->where('estado', 'activa')
            ->where('fecha_fin', '>=', now()->toDateString())
            ->latest();
    }

    public function ventas(): HasMany
    {
        return $this->hasMany(Venta::class);
    }

    public function asistencias(): HasMany
    {
        return $this->hasMany(Asistencia::class);
    }

    public function medidasCorporales(): HasMany
    {
        return $this->hasMany(MedidaCorporal::class);
    }

    public function getNombreCompletoAttribute(): string
    {
        return "{$this->nombres} {$this->apellido_paterno} {$this->apellido_materno}";
    }

    public function getEstadoMembresiaAttribute(): string
    {
        $membresia = $this->membresiaActiva;
        if (!$membresia) return 'inactivo';
        $dias = now()->diffInDays($membresia->fecha_fin, false);
        if ($dias < 0) return 'vencido';
        if ($dias <= 5) return 'por_vencer';
        return 'activo';
    }

    public function getDiasRestantesAttribute(): int
    {
        $membresia = $this->membresiaActiva;
        if (!$membresia) return 0;
        return max(0, (int) now()->diffInDays($membresia->fecha_fin, false));
    }

    public function getWhatsappUrlAttribute(): string
    {
        $membresia = $this->membresiaActiva;

        if (!$membresia || !$this->telefono) {
            return '#';
        }

        $dias     = $this->dias_restantes;
        $duracion = $membresia->plan?->duracion_dias ?? 0;

        $nombre = $this->nombres;

        if ($duracion === 1 && $dias === 0) {
            $mensaje = "\u{00A1}Hola, {$nombre}! \u{1F44B} Qué gusto que nos hayas visitado hoy en Yuri's Gym Hilario Mendivil. \u{00A1}Esperamos que hayas tenido un excelente entrenamiento!\n\n"
                . "\u{00BF}Te gustaría hacer del ejercicio parte de tu rutina? Tenemos planes mensuales pensados para que alcances tus metas más rápido y con mejores beneficios. "
                . "Si te interesa, pásate por recepción y te contamos cómo unirte a nuestra comunidad. \u{00A1}Te esperamos pronto! \u{1F4AA}";
        } elseif ($duracion > 1 && $dias >= 1 && $dias <= 5) {
            $mensaje = "\u{00A1}Hola, {$nombre}! \u{1F3CB}\u{FE0F}\u{200D}\u{2642}\u{FE0F} Te saluda el equipo de Yuri's Gym Hilario Mendivil.\n\n"
                . "Queremos recordarte que a tu plan le quedan *{$dias} días* para vencer. "
                . "\u{00A1}No dejes que tu progreso se detenga! Te esperamos en recepción para renovar y seguir entrenando con todo. \u{00A1}Vamos por más!";
        } else {
            return '#';
        }

        return 'https://wa.me/51' . $this->telefono . '?text=' . urlencode($mensaje);
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class CierreCaja extends Model
{
    protected $table = 'cierres_caja';

    protected $fillable = [
        'fecha', 'efectivo_sistema', 'yape_sistema', 'plin_sistema',
        'transferencia_sistema', 'efectivo_real', 'diferencia', 'observaciones', 'user_id',
    ];

    protected $casts = ['fecha' => 'date'];

    public function cerradoPor(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function getTotalSistemaAttribute(): float
    {
        return $this->efectivo_sistema + $this->yape_sistema + $this->plin_sistema + $this->transferencia_sistema;
    }
}

<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Plan extends Model
{
    protected $table = 'planes';

    protected $fillable = ['nombre', 'descripcion', 'precio', 'duracion_dias', 'activo'];

    protected $casts = ['activo' => 'boolean', 'precio' => 'decimal:2'];

    public function membresias(): HasMany
    {
        return $this->hasMany(Membresia::class);
    }

    public function calcularFechaFin(Carbon $fechaInicio): Carbon
    {
        return $fechaInicio->copy()->addDays($this->duracion_dias);
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class MedidaCorporal extends Model
{
    protected $table = 'medidas_corporales';

    protected $fillable = [
        'cliente_id', 'fecha', 'peso', 'estatura', 'imc',
        'grasa_corporal', 'masa_muscular', 'cintura', 'cadera', 'notas', 'user_id',
    ];

    protected $casts = ['fecha' => 'date'];

    public function cliente(): BelongsTo
    {
        return $this->belongsTo(Cliente::class);
    }

    public function registradoPor(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public static function calcularIMC(float $peso, float $estatura): float
    {
        $estaturaMetros = $estatura / 100;
        return round($peso / ($estaturaMetros ** 2), 2);
    }
}

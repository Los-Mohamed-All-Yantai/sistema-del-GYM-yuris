<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Producto extends Model
{
    protected $fillable = [
        'categoria_id', 'codigo', 'nombre', 'marca', 'descripcion',
        'precio_compra', 'precio_venta', 'stock', 'stock_minimo', 'proveedor', 'activo',
    ];

    protected $casts = [
        'activo' => 'boolean',
        'precio_compra' => 'decimal:2',
        'precio_venta' => 'decimal:2',
    ];

    public function categoria(): BelongsTo
    {
        return $this->belongsTo(Categoria::class);
    }

    public function detalleVentas(): HasMany
    {
        return $this->hasMany(DetalleVenta::class);
    }

    public function getEstadoStockAttribute(): string
    {
        if ($this->stock <= 0) return 'sin_stock';
        if ($this->stock <= $this->stock_minimo) return 'stock_bajo';
        return 'disponible';
    }

    public function getValorInventarioAttribute(): float
    {
        return $this->stock * $this->precio_venta;
    }
}

<?php

namespace App\Providers\Filament;

use Filament\Http\Middleware\Authenticate;
use Filament\Http\Middleware\AuthenticateSession;
use Filament\Http\Middleware\DisableBladeIconComponents;
use Filament\Http\Middleware\DispatchServingFilamentEvent;
use Filament\Navigation\NavigationGroup;
use Filament\Panel;
use Filament\PanelProvider;
use Filament\Support\Colors\Color;
use App\Filament\Widgets\ClientesPorVencerWidget;
use App\Filament\Widgets\InscripcionesChartWidget;
use App\Filament\Widgets\StatsOverviewWidget;
use Filament\Widgets\AccountWidget;
use Illuminate\Support\HtmlString;
use Illuminate\Cookie\Middleware\AddQueuedCookiesToResponse;
use Illuminate\Cookie\Middleware\EncryptCookies;
use Illuminate\Foundation\Http\Middleware\PreventRequestForgery;
use Illuminate\Routing\Middleware\SubstituteBindings;
use Illuminate\Session\Middleware\StartSession;
use Illuminate\View\Middleware\ShareErrorsFromSession;

class AdminPanelProvider extends PanelProvider
{
    public function panel(Panel $panel): Panel
    {
        return $panel
            ->default()
            ->id('admin')
            ->path('admin')
            ->login()
            ->brandName("Yuri's Gym")
            ->favicon(asset('favicon.svg'))
            ->colors(['primary' => Color::Blue])
            ->discoverResources(in: app_path('Filament/Resources'), for: 'App\Filament\Resources')
            ->pages([\Filament\Pages\Dashboard::class])
            ->discoverPages(in: app_path('Filament/Pages'), for: 'App\Filament\Pages')
            ->widgets([
                AccountWidget::class,
                StatsOverviewWidget::class,
                InscripcionesChartWidget::class,
                ClientesPorVencerWidget::class,
            ])
            ->navigationGroups([
                NavigationGroup::make()->label('Membresías'),
                NavigationGroup::make()->label('Tienda'),
                NavigationGroup::make()->label('Seguimiento'),
                NavigationGroup::make()->label('Administración'),
            ])
            ->middleware([
                EncryptCookies::class,
                AddQueuedCookiesToResponse::class,
                StartSession::class,
                AuthenticateSession::class,
                ShareErrorsFromSession::class,
                PreventRequestForgery::class,
                SubstituteBindings::class,
                DisableBladeIconComponents::class,
                DispatchServingFilamentEvent::class,
            ])
            ->authMiddleware([Authenticate::class])
            ->renderHook(
                'panels::body.end',
                function (): HtmlString {
                    // Listener para renovaciones (sin redirección, mismo componente Livewire)
                    $html = '<script>
                        document.addEventListener("livewire:initialized", () => {
                            Livewire.on("open-ticket", (event) => {
                                window.open(event.url, "_blank");
                            });
                        });
                    </script>';

                    // Ticket de inscripción: viene vía session flash tras el redirect
                    if (session()->has('pending_ticket')) {
                        $url = e(session()->pull('pending_ticket'));
                        $html .= '<script>
                            (function () {
                                var ticketUrl = "' . $url . '";
                                var win = window.open(ticketUrl, "_blank");
                                if (!win || win.closed || typeof win.closed === "undefined") {
                                    // Popup bloqueado: mostrar barra flotante de respaldo
                                    document.addEventListener("DOMContentLoaded", function () {
                                        var bar = document.createElement("div");
                                        bar.style.cssText = "position:fixed;bottom:24px;right:24px;z-index:99999;background:#1d4ed8;color:#fff;padding:14px 20px;border-radius:10px;box-shadow:0 4px 16px rgba(0,0,0,.35);font-family:sans-serif;font-size:14px;display:flex;align-items:center;gap:12px;";
                                        bar.innerHTML = \'<span>🖨️</span><a href="\' + ticketUrl + \'" target="_blank" style="color:#fff;font-weight:700;text-decoration:none;">Imprimir ticket de inscripción</a><span onclick="this.parentElement.remove()" style="cursor:pointer;opacity:.7;font-size:18px;">✕</span>\';
                                        document.body.appendChild(bar);
                                    });
                                }
                            })();
                        </script>';
                    }

                    return new HtmlString($html);
                }
            );
    }
}

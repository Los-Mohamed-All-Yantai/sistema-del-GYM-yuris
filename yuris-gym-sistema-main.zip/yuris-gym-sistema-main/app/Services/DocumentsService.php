<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class DocumentsService
{
    /**
     * Busca datos de un DNI (8 dígitos) via RENIEC.
     *
     * @return array{success: bool, message?: string, data?: array}
     */
    public function buscarDni(string $dni): array
    {
        $dni = trim($dni);

        if (strlen($dni) !== 8 || !ctype_digit($dni)) {
            return ['success' => false, 'message' => 'El DNI debe tener exactamente 8 dígitos.'];
        }

        // Intento 1: apis.net.pe (más confiable para RENIEC)
        $tokenNet = config('services.documents.apis_net_pe_token');
        if (!empty($tokenNet)) {
            $result = $this->fetchApisNetPe('dni', $dni, $tokenNet);
            if ($result['success']) return $result;
        }

        // Intento 2: apisperu.com
        $tokenPeru = config('services.documents.apis_peru_token');
        if (!empty($tokenPeru)) {
            $result = $this->fetchApisPeru('dni', $dni, $tokenPeru);
            if ($result['success']) return $result;
        }

        return ['success' => false, 'message' => 'No se pudo consultar RENIEC. Configura DOCUMENTS_APIS_NET_PE_TOKEN en .env o ingresa el nombre manualmente.'];
    }

    private function fetchApisNetPe(string $type, string $numero, string $token): array
    {
        try {
            $url = "https://api.apis.net.pe/v2/reniec/{$type}?numero={$numero}";
            $response = Http::timeout(8)
                ->withHeaders(['Authorization' => "Bearer {$token}", 'Referer' => 'https://apis.net.pe'])
                ->get($url);

            $json = $response->json();

            if ($response->successful() && !empty($json['nombres'])) {
                return [
                    'success' => true,
                    'data'    => [
                        'nombres'          => $json['nombres'] ?? '',
                        'apellidoPaterno'  => $json['apellidoPaterno'] ?? '',
                        'apellidoMaterno'  => $json['apellidoMaterno'] ?? '',
                        'codVerifica'      => $json['codVerifica'] ?? '',
                    ],
                ];
            }

            return ['success' => false, 'message' => $json['message'] ?? 'DNI no encontrado en apis.net.pe'];
        } catch (\Throwable $e) {
            Log::warning('apis.net.pe DNI error: ' . $e->getMessage());
            return ['success' => false, 'message' => 'Error al consultar apis.net.pe'];
        }
    }

    private function fetchApisPeru(string $type, string $numero, string $token): array
    {
        try {
            $url = "https://dniruc.apisperu.com/api/v1/{$type}/{$numero}?token={$token}";
            $response = Http::timeout(8)->get($url);
            $json = $response->json();

            if (!is_array($json) || ($json['success'] ?? true) === false) {
                return ['success' => false, 'message' => 'DNI no encontrado en apisperu.com'];
            }

            return [
                'success' => true,
                'data'    => [
                    'nombres'         => $json['nombres'] ?? '',
                    'apellidoPaterno' => $json['apellidoPaterno'] ?? '',
                    'apellidoMaterno' => $json['apellidoMaterno'] ?? '',
                ],
            ];
        } catch (\Throwable $e) {
            Log::warning('apisperu.com DNI error: ' . $e->getMessage());
            return ['success' => false, 'message' => 'Error al consultar apisperu.com'];
        }
    }
}

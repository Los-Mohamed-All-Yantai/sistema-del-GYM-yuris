<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ClienteResource\Pages;
use App\Models\Cliente;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Resources\Resource;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Schema;
use Filament\Actions;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;

class ClienteResource extends Resource
{
    protected static ?string $model = Cliente::class;
    protected static ?string $navigationLabel = 'Clientes';
    protected static ?string $modelLabel = 'Cliente';
    protected static ?string $pluralModelLabel = 'Clientes';
    protected static ?int $navigationSort = 1;

    public static function getNavigationIcon(): string|\BackedEnum|null
    {
        return 'heroicon-o-users';
    }

    public static function getNavigationGroup(): string|\UnitEnum|null
    {
        return 'Membresías';
    }

    public static function form(Schema $schema): Schema
    {
        return $schema->schema([
            Section::make('Datos personales')->schema([
                TextInput::make('dni')
                    ->label('DNI')->required()->maxLength(15)->unique(ignoreRecord: true)
                    ->rules(['regex:/^\d{8}$/']),
                TextInput::make('nombres')->label('Nombres')->required()->maxLength(100),
                TextInput::make('apellido_paterno')->label('Apellido Paterno')->required()->maxLength(100),
                TextInput::make('apellido_materno')->label('Apellido Materno')->maxLength(100),
                TextInput::make('telefono')->label('Teléfono')->tel()->maxLength(9)->minLength(9)
                    ->extraInputAttributes([
                        'maxlength'   => '9',
                        'inputmode'   => 'numeric',
                        'oninput'     => "this.value = this.value.replace(/[^0-9]/g, '').slice(0, 9);",
                    ])
                    ->rules(['regex:/^\d{9}$/']),
                TextInput::make('email')->label('Email')->email()->maxLength(150),
                DatePicker::make('fecha_nacimiento')->label('Fecha de Nacimiento')->maxDate(now()),
                Toggle::make('activo')->label('Activo')->default(true),
            ])->columns(2),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->modifyQueryUsing(fn (Builder $query) => $query->with('membresiaActiva.plan'))
            ->columns([
                Tables\Columns\TextColumn::make('dni')->label('DNI')->searchable()->sortable(),
                Tables\Columns\TextColumn::make('nombre_completo')->label('Nombre Completo')
                    ->searchable(['nombres', 'apellido_paterno', 'apellido_materno']),
                Tables\Columns\TextColumn::make('telefono')->label('Teléfono'),
                Tables\Columns\TextColumn::make('membresiaActiva.fecha_fin')->label('Vence')->date('d/m/Y'),
                Tables\Columns\TextColumn::make('dias_restantes')->label('Días Rest.')->badge()
                    ->color(fn (Cliente $record) => match ($record->estado_membresia) {
                        'activo'     => 'success',
                        'por_vencer' => 'warning',
                        default      => 'danger',
                    }),
                Tables\Columns\TextColumn::make('estado_membresia')->label('Estado')->badge()
                    ->formatStateUsing(fn (string $state) => match ($state) {
                        'activo'     => 'Activo',
                        'por_vencer' => 'Por vencer',
                        'vencido'    => 'Vencido',
                        default      => 'Sin membresía',
                    })
                    ->color(fn (string $state) => match ($state) {
                        'activo'     => 'success',
                        'por_vencer' => 'warning',
                        default      => 'danger',
                    }),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('estado')
                    ->label('Estado de Membresía')
                    ->options(['activo' => 'Activo', 'por_vencer' => 'Por vencer', 'vencido' => 'Vencido'])
                    ->query(function (Builder $query, array $data): Builder {
                        return match ($data['value'] ?? null) {
                            'activo'     => $query->whereHas('membresiaActiva', fn ($q) => $q->where('fecha_fin', '>', now()->addDays(5))),
                            'por_vencer' => $query->whereHas('membresiaActiva', fn ($q) => $q->whereBetween('fecha_fin', [now(), now()->addDays(5)])),
                            'vencido'    => $query->whereDoesntHave('membresiaActiva'),
                            default      => $query,
                        };
                    }),
            ])
            ->actions([
                Actions\Action::make('whatsapp')->label('WhatsApp')
                    ->icon('heroicon-o-chat-bubble-left')->color('success')
                    ->url(fn (Cliente $record) => $record->whatsapp_url, shouldOpenInNewTab: true)
                    ->visible(function (Cliente $record) {
                    $membresia = $record->membresiaActiva;
                    if (!$membresia || !$record->telefono) return false;
                    $dias     = $record->dias_restantes;
                    $duracion = $membresia->plan?->duracion_dias ?? 0;
                    return ($duracion === 1 && $dias === 0)
                        || ($duracion > 1 && $dias >= 1 && $dias <= 5);
                }),
                Actions\Action::make('qr')->label('Ver QR')->icon('heroicon-o-qr-code')
                    ->url(fn (Cliente $record) => route('cliente.qr', $record))->openUrlInNewTab(),
                Actions\EditAction::make(),
                Actions\DeleteAction::make(),
            ])
            ->bulkActions([Actions\BulkActionGroup::make([Actions\DeleteBulkAction::make()])])
            ->defaultSort('created_at', 'desc');
    }

    public static function getRelations(): array
    {
        return [
            ClienteResource\RelationManagers\MembresiasRelationManager::class,
            ClienteResource\RelationManagers\AsistenciasRelationManager::class,
            ClienteResource\RelationManagers\MedidasRelationManager::class,
        ];
    }

    public static function getPages(): array
    {
        return [
            'index'  => Pages\ListClientes::route('/'),
            'create' => Pages\CreateCliente::route('/create'),
            'edit'   => Pages\EditCliente::route('/{record}/edit'),
        ];
    }

    public static function getNavigationBadge(): ?string
    {
        return (string) static::getModel()::whereHas('membresiaActiva', fn ($q) =>
            $q->whereBetween('fecha_fin', [now(), now()->addDays(5)])
        )->count() ?: null;
    }

    public static function getNavigationBadgeColor(): ?string
    {
        return 'warning';
    }
}

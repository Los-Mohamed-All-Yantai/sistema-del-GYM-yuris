<?php

namespace App\Filament\Resources\ClienteResource\Pages;

use App\Filament\Resources\ClienteResource;
use App\Models\Membresia;
use App\Models\Plan;
use App\Services\DocumentsService;
use Carbon\Carbon;
use Filament\Actions\Action as FormAction;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Notifications\Notification;
use Filament\Resources\Pages\CreateRecord;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Components\Utilities\Get;
use Filament\Schemas\Components\Utilities\Set;
use Filament\Schemas\Schema;
use Illuminate\Support\Str;

class CreateCliente extends CreateRecord
{
    protected static string $resource = ClienteResource::class;

    protected static ?string $title = 'Nueva Inscripción';

    public function form(Schema $schema): Schema
    {
        return $schema->schema([
            Section::make('Datos del Cliente')->schema([

                TextInput::make('dni')
                    ->label('DNI')
                    ->required()
                    ->maxLength(8)
                    ->minLength(8)
                    ->unique('clientes', 'dni', ignoreRecord: true)
                    ->rules(['regex:/^\d{8}$/'])
                    ->placeholder('12345678')
                    ->live(onBlur: true)
                    ->extraAttributes(['x-on:keydown.enter' => '$event.target.blur()'])
                    ->helperText('Ingresa 8 dígitos y presiona Tab/Enter, o usa el botón 🔍')
                    ->suffixAction(
                        FormAction::make('buscar_reniec')
                            ->icon('heroicon-o-magnifying-glass')
                            ->tooltip('Buscar en RENIEC')
                            ->color('info')
                            ->action(function (Get $get, Set $set): void {
                                static::buscarDni($get('dni'), $set);
                            })
                    )
                    ->afterStateUpdated(function (?string $state, Set $set): void {
                        if (strlen((string) $state) === 8 && ctype_digit((string) $state)) {
                            static::buscarDni($state, $set);
                        }
                    }),

                TextInput::make('nombres')
                    ->label('Nombres')
                    ->required()
                    ->maxLength(100),

                TextInput::make('apellido_paterno')
                    ->label('Apellido Paterno')
                    ->required()
                    ->maxLength(100),

                TextInput::make('apellido_materno')
                    ->label('Apellido Materno')
                    ->maxLength(100),

                TextInput::make('telefono')
                    ->label('Teléfono')
                    ->tel()
                    ->maxLength(15),

                TextInput::make('email')
                    ->label('Email')
                    ->email()
                    ->maxLength(150),

            ])->columns(2),

            Section::make('Membresía Inicial')->schema([
                Select::make('plan_id')
                    ->label('Plan')
                    ->options(Plan::where('activo', true)->pluck('nombre', 'id'))
                    ->required()->live()
                    ->afterStateUpdated(function ($state, Set $set) {
                        $plan = Plan::find($state);
                        if ($plan) {
                            $set('precio_pagado', $plan->precio);
                            $set('fecha_fin', now()->addDays($plan->duracion_dias)->format('Y-m-d'));
                        }
                    }),

                DatePicker::make('fecha_inicio')
                    ->label('Fecha Inicio')
                    ->default(now())->required()->live()
                    ->afterStateUpdated(function ($state, Get $get, Set $set) {
                        $plan = Plan::find($get('plan_id'));
                        if ($plan && $state) {
                            $set('fecha_fin', Carbon::parse($state)->addDays($plan->duracion_dias)->format('Y-m-d'));
                        }
                    }),

                DatePicker::make('fecha_fin')
                    ->label('Fecha Fin')
                    ->disabled()
                    ->dehydrated(),

                TextInput::make('precio_pagado')
                    ->label('Precio Pagado')
                    ->numeric()->prefix('S/')
                    ->required(),

                Select::make('metodo_pago')
                    ->label('Método de Pago')
                    ->options(['efectivo' => 'Efectivo', 'yape' => 'Yape', 'plin' => 'Plin', 'transferencia' => 'Transferencia'])
                    ->required(),

                FileUpload::make('voucher')
                    ->label('Voucher (Yape/Plin)')
                    ->image()
                    ->directory('vouchers'),

                Textarea::make('observaciones')
                    ->label('Observaciones')
                    ->columnSpanFull(),
            ])->columns(2),
        ]);
    }

    protected static function buscarDni(?string $dni, Set $set): void
    {
        $dni = trim((string) $dni);

        if (strlen($dni) !== 8 || !ctype_digit($dni)) {
            Notification::make()
                ->title('Ingresa un DNI de 8 dígitos válido.')
                ->warning()
                ->send();
            return;
        }

        $result = app(DocumentsService::class)->buscarDni($dni);

        if (!($result['success'] ?? false)) {
            Notification::make()
                ->title('No encontrado en RENIEC')
                ->body($result['message'] ?? 'Ingresa el nombre manualmente.')
                ->warning()
                ->send();
            return;
        }

        $data = $result['data'] ?? [];

        if (!empty($data['nombres'])) {
            $set('nombres', $data['nombres']);
        }
        if (!empty($data['apellidoPaterno'])) {
            $set('apellido_paterno', $data['apellidoPaterno']);
        }
        if (!empty($data['apellidoMaterno'])) {
            $set('apellido_materno', $data['apellidoMaterno']);
        }

        Notification::make()
            ->title('✅ Datos encontrados en RENIEC')
            ->body(trim(($data['nombres'] ?? '') . ' ' . ($data['apellidoPaterno'] ?? '') . ' ' . ($data['apellidoMaterno'] ?? '')))
            ->success()
            ->send();
    }

    protected function mutateFormDataBeforeCreate(array $data): array
    {
        $data['codigo_qr'] = (string) Str::uuid();
        return $data;
    }

    protected function afterCreate(): void
    {
        $record = $this->getRecord();
        $data   = $this->form->getRawState();

        if (!empty($data['plan_id'])) {
            $plan = Plan::find($data['plan_id']);

            // FileUpload devuelve array; tomamos el primer elemento si aplica
            $voucher = $data['voucher'] ?? null;
            if (is_array($voucher)) {
                $voucher = array_values(array_filter($voucher))[0] ?? null;
            }

            // Las fechas pueden venir como string o Carbon; normalizamos a string
            $fechaInicio = $data['fecha_inicio'] ?? now()->toDateString();
            $fechaFin    = $data['fecha_fin']
                ? (is_string($data['fecha_fin']) ? $data['fecha_fin'] : \Carbon\Carbon::parse($data['fecha_fin'])->toDateString())
                : $plan->calcularFechaFin(\Carbon\Carbon::parse($fechaInicio))->toDateString();

            $membresia = Membresia::create([
                'cliente_id'    => $record->id,
                'plan_id'       => $data['plan_id'],
                'fecha_inicio'  => $fechaInicio,
                'fecha_fin'     => $fechaFin,
                'precio_pagado' => $data['precio_pagado'] ?? $plan->precio,
                'metodo_pago'   => $data['metodo_pago'],
                'voucher'       => $voucher,
                'observaciones' => $data['observaciones'] ?? null,
                'estado'        => 'activa',
                'user_id'       => auth()->id(),
            ]);

            session()->flash('pending_ticket', route('ticket.inscripcion', $membresia->id));
        }
    }

    protected function getRedirectUrl(): string
    {
        return $this->getResource()::getUrl('index');
    }
}

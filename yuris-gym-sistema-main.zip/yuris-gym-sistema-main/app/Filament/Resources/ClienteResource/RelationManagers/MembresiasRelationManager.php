<?php

namespace App\Filament\Resources\ClienteResource\RelationManagers;

use App\Models\Plan;
use Carbon\Carbon;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Schemas\Components\Utilities\Get;
use Filament\Schemas\Components\Utilities\Set;
use Filament\Resources\RelationManagers\RelationManager;
use Filament\Schemas\Schema;
use Filament\Actions;
use Filament\Tables;
use Filament\Tables\Table;

class MembresiasRelationManager extends RelationManager
{
    protected static string $relationship = 'membresias';
    protected static ?string $title = 'Membresías / Renovaciones';

    public function form(Schema $schema): Schema
    {
        return $schema->schema([
            Select::make('plan_id')->label('Plan')
                ->options(Plan::where('activo', true)->pluck('nombre', 'id'))
                ->required()->live()
                ->afterStateUpdated(function ($state, Set $set, Get $get) {
                    $plan = Plan::find($state);
                    if ($plan) {
                        $set('precio_pagado', $plan->precio);
                        $inicio = $get('fecha_inicio') ? Carbon::parse($get('fecha_inicio')) : now();
                        $set('fecha_fin', $plan->calcularFechaFin($inicio)->format('Y-m-d'));
                    }
                }),
            DatePicker::make('fecha_inicio')->label('Inicio')->default(now())->required()->live()
                ->afterStateUpdated(function ($state, Get $get, Set $set) {
                    $plan = Plan::find($get('plan_id'));
                    if ($plan && $state) {
                        $set('fecha_fin', Carbon::parse($state)->addDays($plan->duracion_dias)->format('Y-m-d'));
                    }
                }),
            DatePicker::make('fecha_fin')->label('Fin')->disabled()->dehydrated(),
            TextInput::make('precio_pagado')->label('Precio Pagado')->numeric()->prefix('S/')->required(),
            Select::make('metodo_pago')->label('Método de Pago')
                ->options(['efectivo' => 'Efectivo', 'yape' => 'Yape', 'plin' => 'Plin', 'transferencia' => 'Transferencia'])
                ->required(),
            FileUpload::make('voucher')->label('Voucher')->image()->directory('vouchers'),
            Textarea::make('observaciones')->label('Observaciones')->columnSpanFull(),
        ])->columns(2);
    }

    public function table(Table $table): Table
    {
        return $table->columns([
            Tables\Columns\TextColumn::make('plan.nombre')->label('Plan'),
            Tables\Columns\TextColumn::make('fecha_inicio')->label('Inicio')->date('d/m/Y'),
            Tables\Columns\TextColumn::make('fecha_fin')->label('Fin')->date('d/m/Y'),
            Tables\Columns\TextColumn::make('precio_pagado')->label('Precio')->money('PEN'),
            Tables\Columns\TextColumn::make('metodo_pago')->label('Pago')->badge(),
            Tables\Columns\TextColumn::make('estado')->badge()
                ->color(fn (string $state) => match ($state) {
                    'activa' => 'success', 'vencida' => 'warning', default => 'danger',
                }),
        ])
        ->defaultSort('created_at', 'desc')
        ->headerActions([
            Actions\CreateAction::make()->label('Nueva Renovación')
                ->mutateFormDataUsing(function (array $data) {
                    $voucher = $data['voucher'] ?? null;
                    if (is_array($voucher)) {
                        $voucher = array_values(array_filter($voucher))[0] ?? null;
                    }
                    $data['voucher'] = $voucher;
                    $data['estado']  = 'activa';
                    $data['user_id'] = auth()->id();
                    return $data;
                })
                ->after(function (\App\Models\Membresia $record) {
                    $this->dispatch('open-ticket', url: route('ticket.renovacion', $record->id));
                }),
        ])
        ->actions([Actions\EditAction::make(), Actions\DeleteAction::make()]);
    }
}

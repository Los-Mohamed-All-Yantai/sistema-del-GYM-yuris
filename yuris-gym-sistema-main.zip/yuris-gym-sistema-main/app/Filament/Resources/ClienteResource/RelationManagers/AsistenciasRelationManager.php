<?php

namespace App\Filament\Resources\ClienteResource\RelationManagers;

use Filament\Forms\Components\DateTimePicker;
use Filament\Forms\Components\Select;
use Filament\Resources\RelationManagers\RelationManager;
use Filament\Schemas\Schema;
use Filament\Actions;
use Filament\Tables;
use Filament\Tables\Table;

class AsistenciasRelationManager extends RelationManager
{
    protected static string $relationship = 'asistencias';
    protected static ?string $title = 'Asistencias';

    public function form(Schema $schema): Schema
    {
        return $schema->schema([
            DateTimePicker::make('entrada_at')->label('Entrada')->required()->default(now()),
            DateTimePicker::make('salida_at')->label('Salida'),
            Select::make('tipo_acceso')->label('Tipo')->options(['qr' => 'QR', 'manual' => 'Manual'])->default('manual'),
        ]);
    }

    public function table(Table $table): Table
    {
        return $table->columns([
            Tables\Columns\TextColumn::make('entrada_at')->label('Entrada')->dateTime('d/m/Y H:i')->sortable(),
            Tables\Columns\TextColumn::make('salida_at')->label('Salida')->dateTime('d/m/Y H:i'),
            Tables\Columns\TextColumn::make('duracion')->label('Duración'),
            Tables\Columns\TextColumn::make('tipo_acceso')->label('Acceso')->badge()
                ->color(fn (string $state) => $state === 'qr' ? 'success' : 'info'),
        ])
        ->defaultSort('entrada_at', 'desc')
        ->headerActions([Actions\CreateAction::make()->label('Registrar Asistencia')])
        ->actions([Actions\EditAction::make()]);
    }
}

<?php

namespace App\Filament\Resources\ClienteResource\RelationManagers;

use App\Models\MedidaCorporal;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Schemas\Components\Utilities\Get;
use Filament\Schemas\Components\Utilities\Set;
use Filament\Resources\RelationManagers\RelationManager;
use Filament\Schemas\Schema;
use Filament\Actions;
use Filament\Tables;
use Filament\Tables\Table;

class MedidasRelationManager extends RelationManager
{
    protected static string $relationship = 'medidasCorporales';
    protected static ?string $title = 'Medidas Corporales';

    public function form(Schema $schema): Schema
    {
        return $schema->schema([
            DatePicker::make('fecha')->label('Fecha')->required()->default(now()),
            TextInput::make('peso')->label('Peso (kg)')->numeric()->live()
                ->afterStateUpdated(function ($state, Get $get, Set $set) {
                    $estatura = $get('estatura');
                    if ($state && $estatura) $set('imc', MedidaCorporal::calcularIMC((float) $state, (float) $estatura));
                }),
            TextInput::make('estatura')->label('Estatura (cm)')->numeric()->live()
                ->afterStateUpdated(function ($state, Get $get, Set $set) {
                    $peso = $get('peso');
                    if ($state && $peso) $set('imc', MedidaCorporal::calcularIMC((float) $peso, (float) $state));
                }),
            TextInput::make('imc')->label('IMC')->numeric()->disabled()->dehydrated(),
            TextInput::make('grasa_corporal')->label('Grasa Corporal (%)')->numeric(),
            TextInput::make('masa_muscular')->label('Masa Muscular (kg)')->numeric(),
            TextInput::make('cintura')->label('Cintura (cm)')->numeric(),
            TextInput::make('cadera')->label('Cadera (cm)')->numeric(),
            Textarea::make('notas')->label('Notas')->columnSpanFull(),
        ])->columns(2);
    }

    public function table(Table $table): Table
    {
        return $table->columns([
            Tables\Columns\TextColumn::make('fecha')->label('Fecha')->date('d/m/Y')->sortable(),
            Tables\Columns\TextColumn::make('peso')->label('Peso')->suffix(' kg'),
            Tables\Columns\TextColumn::make('estatura')->label('Estatura')->suffix(' cm'),
            Tables\Columns\TextColumn::make('imc')->label('IMC'),
            Tables\Columns\TextColumn::make('grasa_corporal')->label('Grasa %'),
            Tables\Columns\TextColumn::make('masa_muscular')->label('Músculo kg'),
        ])
        ->defaultSort('fecha', 'desc')
        ->headerActions([
            Actions\CreateAction::make()->label('Registrar Medidas')
                ->mutateFormDataUsing(fn (array $data) => array_merge($data, ['user_id' => auth()->id()])),
        ])
        ->actions([Actions\EditAction::make(), Actions\DeleteAction::make()]);
    }
}

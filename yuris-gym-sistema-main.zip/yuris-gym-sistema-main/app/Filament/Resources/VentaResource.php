<?php

namespace App\Filament\Resources;

use App\Filament\Resources\VentaResource\Pages;
use App\Models\Venta;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Resources\Resource;
use Filament\Schemas\Schema;
use Filament\Actions;
use Filament\Tables;
use Filament\Tables\Table;

class VentaResource extends Resource
{
    protected static ?string $model = Venta::class;
    protected static ?string $navigationLabel = 'Historial Ventas';
    protected static ?string $modelLabel = 'Venta';
    protected static ?string $pluralModelLabel = 'Ventas';
    protected static ?int $navigationSort = 1;

    public static function getNavigationIcon(): string|\BackedEnum|null { return 'heroicon-o-receipt-percent'; }
    public static function getNavigationGroup(): string|\UnitEnum|null { return 'Tienda'; }

    public static function form(Schema $schema): Schema
    {
        return $schema->schema([
            Select::make('cliente_id')->label('Cliente')
                ->relationship('cliente', 'nombres')->searchable()->preload(),
            Select::make('metodo_pago')->label('Método de Pago')
                ->options(['efectivo' => 'Efectivo', 'yape' => 'Yape', 'plin' => 'Plin', 'transferencia' => 'Transferencia'])
                ->required(),
            TextInput::make('total')->label('Total')->numeric()->prefix('S/')->required(),
            Select::make('estado')->label('Estado')
                ->options(['completada' => 'Completada', 'anulada' => 'Anulada'])->required(),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table->columns([
            Tables\Columns\TextColumn::make('created_at')->label('Fecha/Hora')->dateTime('d/m/Y H:i')->sortable(),
            Tables\Columns\TextColumn::make('cliente.nombre_completo')->label('Cliente')
                ->searchable(['clientes.nombres', 'clientes.apellido_paterno']),
            Tables\Columns\TextColumn::make('detalles_count')->counts('detalles')->label('Productos'),
            Tables\Columns\TextColumn::make('total')->label('Total')->money('PEN')->sortable(),
            Tables\Columns\TextColumn::make('metodo_pago')->label('Pago')->badge()
                ->color(fn (string $state) => match ($state) {
                    'efectivo' => 'success', 'yape' => 'info', 'plin' => 'warning', default => 'gray',
                }),
            Tables\Columns\TextColumn::make('estado')->badge()
                ->color(fn (string $state) => $state === 'completada' ? 'success' : 'danger'),
            Tables\Columns\TextColumn::make('vendidoPor.name')->label('Registrado por'),
        ])
        ->filters([
            Tables\Filters\SelectFilter::make('metodo_pago')->label('Método de Pago')
                ->options(['efectivo' => 'Efectivo', 'yape' => 'Yape', 'plin' => 'Plin', 'transferencia' => 'Transferencia']),
            Tables\Filters\SelectFilter::make('estado')->options(['completada' => 'Completada', 'anulada' => 'Anulada']),
            Tables\Filters\Filter::make('hoy')->label('Solo hoy')
                ->query(fn ($query) => $query->whereDate('created_at', today())),
        ])
        ->defaultSort('created_at', 'desc')
        ->actions([
            Actions\Action::make('boleta')->label('Ticket')->icon('heroicon-o-printer')
                ->url(fn (Venta $record) => route('ticket.venta', $record))->openUrlInNewTab(),
            Actions\ViewAction::make(),
            Actions\Action::make('anular')->label('Anular')->icon('heroicon-o-x-circle')->color('danger')
                ->requiresConfirmation()
                ->visible(fn (Venta $record) => $record->estado === 'completada')
                ->action(fn (Venta $record) => $record->update(['estado' => 'anulada'])),
        ])
        ->bulkActions([Actions\BulkActionGroup::make([Actions\DeleteBulkAction::make()])]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListVentas::route('/'),
            'view'  => Pages\ViewVenta::route('/{record}'),
        ];
    }

    public static function canCreate(): bool { return false; }

    public static function getNavigationBadge(): ?string
    {
        return (string) static::getModel()::whereDate('created_at', today())->count();
    }

    public static function getNavigationBadgeColor(): ?string { return 'info'; }
}

<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ProductoResource\Pages;
use App\Models\Categoria;
use App\Models\Producto;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Resources\Resource;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Schema;
use Filament\Actions;
use Filament\Tables;
use Filament\Tables\Table;

class ProductoResource extends Resource
{
    protected static ?string $model = Producto::class;
    protected static ?string $navigationLabel = 'Inventario';
    protected static ?string $modelLabel = 'Producto';
    protected static ?string $pluralModelLabel = 'Productos';
    protected static ?int $navigationSort = 2;

    public static function getNavigationIcon(): string|\BackedEnum|null { return 'heroicon-o-cube'; }
    public static function getNavigationGroup(): string|\UnitEnum|null { return 'Tienda'; }

    public static function form(Schema $schema): Schema
    {
        return $schema->schema([
            Section::make('Información del Producto')->schema([
                TextInput::make('codigo')->label('Código')->unique(ignoreRecord: true)->maxLength(50),
                TextInput::make('nombre')->label('Nombre')->required()->maxLength(150),
                Select::make('categoria_id')->label('Categoría')
                    ->options(Categoria::pluck('nombre', 'id'))->searchable()
                    ->createOptionForm([TextInput::make('nombre')->label('Nueva Categoría')->required()])
                    ->createOptionUsing(fn (array $data) => Categoria::create($data)->id),
                TextInput::make('marca')->label('Marca')->maxLength(100),
                TextInput::make('proveedor')->label('Proveedor')->maxLength(150),
                Textarea::make('descripcion')->label('Descripción')->columnSpanFull(),
            ])->columns(2),
            Section::make('Precios y Stock')->schema([
                TextInput::make('precio_compra')->label('Precio Compra (S/)')->numeric()->prefix('S/')->default(0),
                TextInput::make('precio_venta')->label('Precio Venta (S/)')->numeric()->prefix('S/')->required(),
                TextInput::make('stock')->label('Stock Inicial')->numeric()->default(0)->required(),
                TextInput::make('stock_minimo')->label('Stock Mínimo')->numeric()->default(5)->required(),
                Toggle::make('activo')->label('Activo')->default(true),
            ])->columns(2),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table->columns([
            Tables\Columns\TextColumn::make('codigo')->label('Código')->searchable(),
            Tables\Columns\TextColumn::make('nombre')->label('Producto')->searchable()->sortable(),
            Tables\Columns\TextColumn::make('categoria.nombre')->label('Categoría'),
            Tables\Columns\TextColumn::make('precio_venta')->label('Precio')->money('PEN')->sortable(),
            Tables\Columns\TextColumn::make('stock')->label('Stock')->sortable()
                ->color(fn (Producto $record) => match ($record->estado_stock) {
                    'sin_stock'  => 'danger',
                    'stock_bajo' => 'warning',
                    default      => 'success',
                }),
            Tables\Columns\TextColumn::make('estado_stock')->label('Estado')->badge()
                ->formatStateUsing(fn (string $state) => match ($state) {
                    'disponible' => 'Disponible', 'stock_bajo' => 'Stock Bajo', 'sin_stock' => 'Sin Stock', default => $state,
                })
                ->color(fn (string $state) => match ($state) {
                    'disponible' => 'success', 'stock_bajo' => 'warning', default => 'danger',
                }),
        ])
        ->filters([
            Tables\Filters\SelectFilter::make('categoria_id')->label('Categoría')
                ->options(Categoria::pluck('nombre', 'id')),
        ])
        ->actions([Actions\EditAction::make(), Actions\DeleteAction::make()])
        ->bulkActions([Actions\BulkActionGroup::make([Actions\DeleteBulkAction::make()])]);
    }

    public static function getPages(): array
    {
        return [
            'index'  => Pages\ListProductos::route('/'),
            'create' => Pages\CreateProducto::route('/create'),
            'edit'   => Pages\EditProducto::route('/{record}/edit'),
        ];
    }

    public static function getNavigationBadge(): ?string
    {
        $sinStock = static::getModel()::where('stock', '<=', 0)->count();
        return $sinStock > 0 ? (string) $sinStock : null;
    }

    public static function getNavigationBadgeColor(): ?string { return 'danger'; }
}

<?php

namespace App\Filament\Resources;

use App\Filament\Resources\PlanResource\Pages;
use App\Models\Plan;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Resources\Resource;
use Filament\Schemas\Schema;
use Filament\Actions;
use Filament\Tables;
use Filament\Tables\Table;

class PlanResource extends Resource
{
    protected static ?string $model = Plan::class;
    protected static ?string $navigationLabel = 'Planes';
    protected static ?string $modelLabel = 'Plan';
    protected static ?string $pluralModelLabel = 'Planes';
    protected static ?int $navigationSort = 1;

    public static function getNavigationIcon(): string|\BackedEnum|null { return 'heroicon-o-tag'; }
    public static function getNavigationGroup(): string|\UnitEnum|null { return 'Administración'; }

    public static function form(Schema $schema): Schema
    {
        return $schema->schema([
            TextInput::make('nombre')->label('Nombre del Plan')->required()->maxLength(100),
            TextInput::make('precio')->label('Precio (S/)')->numeric()->prefix('S/')->required(),
            TextInput::make('duracion_dias')->label('Duración (días)')->numeric()->required()->minValue(1),
            Textarea::make('descripcion')->label('Descripción'),
            Toggle::make('activo')->label('Activo')->default(true),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table->columns([
            Tables\Columns\TextColumn::make('nombre')->label('Plan')->searchable()->sortable(),
            Tables\Columns\TextColumn::make('precio')->label('Precio')->money('PEN')->sortable(),
            Tables\Columns\TextColumn::make('duracion_dias')->label('Días')->sortable(),
            Tables\Columns\IconColumn::make('activo')->label('Activo')->boolean(),
            Tables\Columns\TextColumn::make('membresias_count')->label('Inscritos')->counts('membresias')->sortable(),
        ])
        ->actions([Actions\EditAction::make(), Actions\DeleteAction::make()])
        ->bulkActions([Actions\BulkActionGroup::make([Actions\DeleteBulkAction::make()])]);
    }

    public static function getPages(): array
    {
        return [
            'index'  => Pages\ListPlanes::route('/'),
            'create' => Pages\CreatePlan::route('/create'),
            'edit'   => Pages\EditPlan::route('/{record}/edit'),
        ];
    }

    public static function canAccess(): bool
    {
        return auth()->user()?->isAdmin() ?? false;
    }
}

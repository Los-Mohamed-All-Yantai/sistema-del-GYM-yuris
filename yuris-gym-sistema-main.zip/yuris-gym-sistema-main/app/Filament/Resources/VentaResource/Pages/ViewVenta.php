<?php

namespace App\Filament\Resources\VentaResource\Pages;

use App\Filament\Resources\VentaResource;
use Filament\Actions;
use Filament\Resources\Pages\ViewRecord;

class ViewVenta extends ViewRecord
{
    protected static string $resource = VentaResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\Action::make('boleta')->label('Imprimir Ticket')->icon('heroicon-o-printer')
                ->url(fn () => route('ticket.venta', $this->record))->openUrlInNewTab(),
        ];
    }
}

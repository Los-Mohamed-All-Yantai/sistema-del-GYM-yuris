<?php

namespace App\Filament\Widgets;

use App\Models\Membresia;
use App\Models\Venta;
use Filament\Widgets\ChartWidget;

class InscripcionesChartWidget extends ChartWidget
{
    protected static ?int $sort = 2;
    protected int|string|array $columnSpan = 'full';
    protected ?string $maxHeight = '300px';

    public function getHeading(): string
    {
        return 'Inscripciones y Ventas — ' . now()->year;
    }

    protected function getData(): array
    {
        $year         = now()->year;
        $currentMonth = now()->month;

        $labels        = [];
        $inscripciones = [];
        $ventas        = [];

        for ($m = 1; $m <= $currentMonth; $m++) {
            $labels[]        = ucfirst(now()->setMonth($m)->locale('es')->isoFormat('MMM'));
            $inscripciones[] = Membresia::whereYear('created_at', $year)
                ->whereMonth('created_at', $m)->count();
            $ventas[]        = (float) Venta::whereYear('created_at', $year)
                ->whereMonth('created_at', $m)
                ->where('estado', 'completada')
                ->sum('total');
        }

        return [
            'labels'   => $labels,
            'datasets' => [
                [
                    'label'           => 'Inscripciones',
                    'data'            => $inscripciones,
                    'backgroundColor' => 'rgba(59, 130, 246, 0.75)',
                    'borderColor'     => 'rgba(59, 130, 246, 1)',
                    'borderWidth'     => 2,
                    'borderRadius'    => 6,
                    'yAxisID'         => 'y',
                    'order'           => 2,
                ],
                [
                    'label'                => 'Ventas (S/)',
                    'data'                 => $ventas,
                    'backgroundColor'      => 'rgba(16, 185, 129, 0)',
                    'borderColor'          => 'rgba(16, 185, 129, 1)',
                    'borderWidth'          => 2.5,
                    'pointBackgroundColor' => 'rgba(16, 185, 129, 1)',
                    'pointRadius'          => 4,
                    'pointHoverRadius'     => 6,
                    'tension'              => 0.4,
                    'fill'                 => false,
                    'type'                 => 'line',
                    'yAxisID'              => 'y1',
                    'order'                => 1,
                ],
            ],
        ];
    }

    protected function getType(): string
    {
        return 'bar';
    }

    protected function getOptions(): array
    {
        return [
            'responsive'          => true,
            'maintainAspectRatio' => false,
            'interaction'         => ['mode' => 'index', 'intersect' => false],
            'plugins'             => [
                'legend' => [
                    'position' => 'top',
                    'labels'   => ['usePointStyle' => true, 'padding' => 20],
                ],
            ],
            'scales' => [
                'x'  => [
                    'grid' => ['display' => false],
                ],
                'y'  => [
                    'position'    => 'left',
                    'beginAtZero' => true,
                    'title'       => ['display' => true, 'text' => 'Inscripciones'],
                    'ticks'       => ['stepSize' => 1, 'precision' => 0],
                    'grid'        => ['color' => 'rgba(0,0,0,0.05)'],
                ],
                'y1' => [
                    'position'    => 'right',
                    'beginAtZero' => true,
                    'title'       => ['display' => true, 'text' => 'Ventas (S/)'],
                    'grid'        => ['drawOnChartArea' => false],
                ],
            ],
        ];
    }
}

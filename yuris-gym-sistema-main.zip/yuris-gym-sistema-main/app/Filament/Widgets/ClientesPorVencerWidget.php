<?php

namespace App\Filament\Widgets;

use App\Models\Cliente;
use Filament\Actions;
use Filament\Tables;
use Filament\Tables\Table;
use Filament\Widgets\TableWidget as BaseWidget;

class ClientesPorVencerWidget extends BaseWidget
{
    protected static ?string $heading = 'Clientes por Vencer (próximos 7 días)';
    protected static ?int $sort = 3;
    protected int|string|array $columnSpan = 'full';

    public function table(Table $table): Table
    {
        return $table
            ->query(
                Cliente::whereHas('membresiaActiva', fn ($q) =>
                    $q->whereBetween('fecha_fin', [now(), now()->addDays(7)])
                )->with('membresiaActiva.plan')
            )
            ->columns([
                Tables\Columns\TextColumn::make('dni')->label('DNI'),
                Tables\Columns\TextColumn::make('nombre_completo')->label('Cliente'),
                Tables\Columns\TextColumn::make('telefono')->label('Teléfono'),
                Tables\Columns\TextColumn::make('membresiaActiva.plan.nombre')->label('Plan'),
                Tables\Columns\TextColumn::make('membresiaActiva.fecha_fin')->label('Vence')->date('d/m/Y'),
                Tables\Columns\TextColumn::make('dias_restantes')->label('Días Rest.')->badge()
                    ->color(fn (Cliente $record) => $record->dias_restantes <= 2 ? 'danger' : 'warning'),
            ])
            ->actions([
                Actions\Action::make('whatsapp')->label('WhatsApp')
                    ->icon('heroicon-o-chat-bubble-left')->color('success')
                    ->url(fn (Cliente $record) => $record->whatsapp_url)->openUrlInNewTab(),
            ]);
    }
}

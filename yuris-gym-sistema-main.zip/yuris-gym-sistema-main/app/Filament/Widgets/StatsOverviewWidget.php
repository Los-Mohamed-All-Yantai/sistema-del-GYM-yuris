<?php

namespace App\Filament\Widgets;

use App\Models\Cliente;
use App\Models\Membresia;
use App\Models\Producto;
use App\Models\Venta;
use Filament\Widgets\StatsOverviewWidget as BaseWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;

class StatsOverviewWidget extends BaseWidget
{
    protected static ?int $sort = 1;
    protected ?string $heading = null;

    protected function getStats(): array
    {
        // ── CLIENTES ──────────────────────────────────────────────────────────
        $totalClientes = Cliente::count();
        $activos       = Cliente::whereHas('membresiaActiva')->count();
        $ausentes      = $totalClientes - $activos;

        // Tendencia de altas de clientes: últimos 6 meses
        $altasTrend = [];
        for ($i = 5; $i >= 0; $i--) {
            $m = now()->subMonths($i);
            $altasTrend[] = (int) Cliente::whereYear('created_at', $m->year)
                ->whereMonth('created_at', $m->month)
                ->count();
        }

        // ── VENTAS ────────────────────────────────────────────────────────────
        $ventasHoy = Venta::whereDate('created_at', today())
            ->where('estado', 'completada')
            ->sum('total');

        // Tendencia: últimos 7 días (sparkline ventas diarias)
        $ventasTrend = [];
        for ($i = 6; $i >= 0; $i--) {
            $ventasTrend[] = (float) Venta::whereDate('created_at', now()->subDays($i))
                ->where('estado', 'completada')
                ->sum('total');
        }

        // Ingresos del mes = ventas completadas + membresías cobradas
        $year = now()->year;
        $month = now()->month;

        $ventasMes    = Venta::whereYear('created_at', $year)->whereMonth('created_at', $month)
            ->where('estado', 'completada')->sum('total');
        $membresiasMes = Membresia::whereYear('created_at', $year)->whereMonth('created_at', $month)
            ->sum('precio_pagado');
        $ingresosMes  = $ventasMes + $membresiasMes;

        // Tendencia de ingresos: últimos 6 meses
        $ingresosTrend = [];
        for ($i = 5; $i >= 0; $i--) {
            $m  = now()->subMonths($i);
            $v  = Venta::whereYear('created_at', $m->year)->whereMonth('created_at', $m->month)
                ->where('estado', 'completada')->sum('total');
            $mb = Membresia::whereYear('created_at', $m->year)->whereMonth('created_at', $m->month)
                ->sum('precio_pagado');
            $ingresosTrend[] = (float) ($v + $mb);
        }

        // ── INVENTARIO ────────────────────────────────────────────────────────
        $stockTotal      = (int) Producto::sum('stock');
        $sinStock        = Producto::where('stock', '<=', 0)->count();
        $valorInventario = (float) Producto::selectRaw('SUM(COALESCE(precio_venta,0) * COALESCE(stock,0)) as valor')
            ->value('valor');

        $porVencer = Cliente::whereHas('membresiaActiva', fn ($q) =>
            $q->whereBetween('fecha_fin', [now(), now()->addDays(5)])
        )->count();

        return [
            // ── SECCIÓN CLIENTES ─────────────────────────────────────────────
            Stat::make('Total Clientes', $totalClientes)
                ->description('Registrados en el sistema')
                ->descriptionIcon('heroicon-m-users')
                ->color('info')
                ->chart($altasTrend),

            Stat::make('Clientes Activos', $activos)
                ->description("{$porVencer} por vencer en ≤5 días")
                ->descriptionIcon('heroicon-m-check-badge')
                ->color('success'),

            Stat::make('Ausentes / Vencidos', $ausentes)
                ->description($ausentes > 0 ? 'Sin membresía activa' : 'Todos con plan vigente')
                ->descriptionIcon($ausentes > 0 ? 'heroicon-m-x-circle' : 'heroicon-m-check-circle')
                ->color($ausentes > 0 ? 'danger' : 'success'),

            // ── SECCIÓN VENTAS ───────────────────────────────────────────────
            Stat::make('Ingresos del Día', 'S/ ' . number_format($ventasHoy, 2))
                ->description('Ventas completadas hoy')
                ->descriptionIcon('heroicon-m-currency-dollar')
                ->color('warning')
                ->chart($ventasTrend),

            Stat::make('Ingresos del Mes', 'S/ ' . number_format($ingresosMes, 2))
                ->description('Ventas + membresías — ' . ucfirst(now()->locale('es')->isoFormat('MMMM')))
                ->descriptionIcon('heroicon-m-banknotes')
                ->color('success')
                ->chart($ingresosTrend),

            // ── SECCIÓN INVENTARIO ───────────────────────────────────────────
            Stat::make('Stock Total', number_format($stockTotal) . ' uds.')
                ->description("{$sinStock} producto(s) sin stock")
                ->descriptionIcon('heroicon-m-cube')
                ->color($sinStock > 0 ? 'danger' : 'info'),

            Stat::make('Valor de Inventario', 'S/ ' . number_format($valorInventario, 2))
                ->description('Precio venta × stock actual')
                ->descriptionIcon('heroicon-m-building-storefront')
                ->color('primary'),
        ];
    }
}

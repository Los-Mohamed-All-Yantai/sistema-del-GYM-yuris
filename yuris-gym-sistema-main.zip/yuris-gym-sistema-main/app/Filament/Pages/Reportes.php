<?php

namespace App\Filament\Pages;

use App\Exports\ClientesExport;
use App\Exports\VentasExport;
use App\Models\Membresia;
use App\Models\Venta;
use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Filament\Pages\Page;
use Maatwebsite\Excel\Facades\Excel;
use Symfony\Component\HttpFoundation\BinaryFileResponse;

class Reportes extends Page implements HasForms
{
    use InteractsWithForms;

    protected string $view = 'filament.pages.reportes';

    protected static ?string $navigationLabel = 'Reportes';
    protected static ?string $title = 'Reportes y Exportaciones';
    protected static ?int $navigationSort = 2;

    public static function getNavigationIcon(): string|\BackedEnum|null { return 'heroicon-o-chart-bar'; }
    public static function getNavigationGroup(): string|\UnitEnum|null { return 'Administración'; }

    public ?string $desde = null;
    public ?string $hasta = null;

    public function mount(): void
    {
        $this->desde = now()->startOfMonth()->format('Y-m-d');
        $this->hasta = now()->format('Y-m-d');
    }

    public function exportarClientes(): BinaryFileResponse
    {
        return Excel::download(new ClientesExport(), 'clientes_' . now()->format('Ymd') . '.xlsx');
    }

    public function exportarVentas(): BinaryFileResponse
    {
        return Excel::download(new VentasExport($this->desde, $this->hasta), 'ventas_' . now()->format('Ymd') . '.xlsx');
    }

    public function getResumenMes(): array
    {
        $mes = now()->month;
        $año = now()->year;
        return [
            'inscripciones'       => Membresia::whereYear('created_at', $año)->whereMonth('created_at', $mes)->count(),
            'ingresos_membresias' => Membresia::whereYear('created_at', $año)->whereMonth('created_at', $mes)->sum('precio_pagado'),
            'ventas_count'        => Venta::whereYear('created_at', $año)->whereMonth('created_at', $mes)->where('estado', 'completada')->count(),
            'ingresos_ventas'     => Venta::whereYear('created_at', $año)->whereMonth('created_at', $mes)->where('estado', 'completada')->sum('total'),
            'efectivo'            => Venta::whereYear('created_at', $año)->whereMonth('created_at', $mes)->where('metodo_pago', 'efectivo')->where('estado', 'completada')->sum('total'),
            'digital'             => Venta::whereYear('created_at', $año)->whereMonth('created_at', $mes)->whereIn('metodo_pago', ['yape', 'plin', 'transferencia'])->where('estado', 'completada')->sum('total'),
        ];
    }

    public static function canAccess(): bool
    {
        return auth()->user()?->isAdmin() ?? false;
    }
}

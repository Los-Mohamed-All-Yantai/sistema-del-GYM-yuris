<?php

namespace App\Filament\Pages;

use App\Models\Asistencia;
use App\Models\Cliente;
use Filament\Pages\Page;
use Livewire\Attributes\Computed;

class ControlAcceso extends Page
{
    protected string $view = 'filament.pages.control-acceso';

    protected static ?string $navigationLabel = 'Control de Acceso';
    protected static ?string $title = 'Control de Acceso';
    protected static ?int $navigationSort = 1;

    public static function getNavigationIcon(): string|\BackedEnum|null
    {
        return 'heroicon-o-identification';
    }

    public static function getNavigationGroup(): string|\UnitEnum|null
    {
        return 'Seguimiento';
    }

    public string $dni = '';

    #[Computed]
    public function asistencias()
    {
        return Asistencia::with('cliente')
            ->whereDate('entrada_at', today())
            ->latest('entrada_at')
            ->take(30)
            ->get();
    }

    public function registrarDni(): void
    {
        $dni = trim($this->dni);
        $this->dni = '';

        if (strlen($dni) !== 8 || !ctype_digit($dni)) {
            session()->flash('acceso_denegado', [
                'nombre' => null,
                'razon'  => 'DNI inválido. Ingrese exactamente 8 dígitos numéricos.',
            ]);
            return;
        }

        $cliente = Cliente::where('dni', $dni)->with('membresiaActiva.plan')->first();

        if (!$cliente) {
            session()->flash('acceso_denegado', [
                'nombre' => null,
                'razon'  => "DNI {$dni} no está registrado en el sistema.",
            ]);
            return;
        }

        $membresia = $cliente->membresiaActiva;

        if (!$membresia || !$membresia->estaVigente()) {
            session()->flash('acceso_denegado', [
                'nombre' => strtoupper($cliente->nombre_completo),
                'razon'  => $membresia ? 'MEMBRESÍA VENCIDA' : 'SIN PLAN ACTIVO',
            ]);
            return;
        }

        Asistencia::create([
            'cliente_id'   => $cliente->id,
            'membresia_id' => $membresia->id,
            'entrada_at'   => now(),
            'tipo_acceso'  => 'manual',
        ]);

        $diasRestantes = $membresia->dias_restantes;

        session()->flash('acceso_permitido', [
            'nombre' => strtoupper($cliente->nombre_completo),
            'plan'   => $membresia->plan->nombre,
            'vence'  => $membresia->fecha_fin->format('d/m/Y'),
            'dias'   => $diasRestantes,
            'alerta' => $diasRestantes <= 3,
        ]);

        unset($this->asistencias);
    }
}

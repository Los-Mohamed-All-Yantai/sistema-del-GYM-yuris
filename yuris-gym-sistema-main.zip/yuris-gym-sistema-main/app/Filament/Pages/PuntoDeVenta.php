<?php

namespace App\Filament\Pages;

use App\Models\Cliente;
use App\Models\DetalleVenta;
use App\Models\Producto;
use App\Models\Venta;
use Filament\Notifications\Notification;
use Filament\Pages\Page;
use Illuminate\Support\Facades\DB;

class PuntoDeVenta extends Page
{
    protected string $view = 'filament.pages.punto-de-venta';

    protected static ?string $navigationLabel = 'Punto de Venta';
    protected static ?string $title = 'Punto de Venta';
    protected static ?int $navigationSort = 0;

    public static function getNavigationIcon(): string|\BackedEnum|null { return 'heroicon-o-shopping-cart'; }
    public static function getNavigationGroup(): string|\UnitEnum|null { return 'Tienda'; }

    // Estado del POS
    public ?int    $clienteId      = null;
    public string  $buscarCliente  = '';
    public string  $buscarProducto = '';
    public string  $metodoPago     = 'efectivo';
    public array   $carrito        = [];
    public float   $total          = 0;
    public ?int    $ultimaVentaId  = null;

    public function mount(): void
    {
        $this->carrito = [];
        $this->total   = 0;
    }

    // ── Clientes ──────────────────────────────────────────────────────────────

    public function getClientesFiltrados(): array
    {
        $query = Cliente::select('id', 'nombres', 'apellido_paterno', 'dni')
            ->where('activo', true)
            ->orderBy('apellido_paterno');

        if (strlen($this->buscarCliente) >= 2) {
            $q = $this->buscarCliente;
            $query->where(function ($w) use ($q) {
                $w->where('nombres', 'like', "%{$q}%")
                  ->orWhere('apellido_paterno', 'like', "%{$q}%")
                  ->orWhere('dni', 'like', "%{$q}%");
            });
        }

        return $query->limit(8)->get()
            ->map(fn ($c) => [
                'id'    => $c->id,
                'label' => "{$c->apellido_paterno}, {$c->nombres} · {$c->dni}",
            ])
            ->toArray();
    }

    public function seleccionarCliente(int $id): void
    {
        $this->clienteId     = $id;
        $this->buscarCliente = '';
    }

    public function limpiarCliente(): void
    {
        $this->clienteId     = null;
        $this->buscarCliente = '';
    }

    public function getClienteSeleccionado(): ?string
    {
        if (!$this->clienteId) return null;
        $c = Cliente::find($this->clienteId);
        return $c ? "{$c->apellido_paterno}, {$c->nombres} · {$c->dni}" : null;
    }

    // ── Productos ─────────────────────────────────────────────────────────────

    public function getProductosDisponibles(): array
    {
        if (strlen($this->buscarProducto) < 2) return [];

        return Producto::where('activo', true)
            ->where('stock', '>', 0)
            ->where(fn ($q) =>
                $q->where('nombre', 'like', "%{$this->buscarProducto}%")
                  ->orWhere('codigo', 'like', "%{$this->buscarProducto}%")
            )
            ->limit(8)
            ->get(['id', 'nombre', 'precio_venta', 'stock'])
            ->toArray();
    }

    public function agregarProducto(int $productoId): void
    {
        $producto = Producto::find($productoId);
        if (!$producto || $producto->stock <= 0) {
            Notification::make()->title('Sin stock disponible')->danger()->send();
            return;
        }

        foreach ($this->carrito as &$item) {
            if ($item['id'] === $productoId) {
                if ($item['cantidad'] >= $producto->stock) {
                    Notification::make()->title('Stock máximo alcanzado')->warning()->send();
                    return;
                }
                $item['cantidad']++;
                $item['subtotal'] = round($item['cantidad'] * $item['precio'], 2);
                $this->calcularTotal();
                $this->buscarProducto = '';
                return;
            }
        }

        $this->carrito[] = [
            'id'       => $producto->id,
            'nombre'   => $producto->nombre,
            'precio'   => (float) $producto->precio_venta,
            'stock'    => $producto->stock,
            'cantidad' => 1,
            'subtotal' => (float) $producto->precio_venta,
        ];

        $this->calcularTotal();
        $this->buscarProducto = '';
    }

    public function actualizarCantidad(int $index, int $cantidad): void
    {
        if (!isset($this->carrito[$index])) return;

        if ($cantidad <= 0) {
            $this->eliminarItem($index);
            return;
        }
        if ($cantidad > $this->carrito[$index]['stock']) {
            Notification::make()->title('Stock insuficiente')->warning()->send();
            return;
        }

        $this->carrito[$index]['cantidad'] = $cantidad;
        $this->carrito[$index]['subtotal'] = round($cantidad * $this->carrito[$index]['precio'], 2);
        $this->calcularTotal();
    }

    public function eliminarItem(int $index): void
    {
        array_splice($this->carrito, $index, 1);
        $this->calcularTotal();
    }

    public function limpiarCarrito(): void
    {
        $this->carrito = [];
        $this->total   = 0;
    }

    public function calcularTotal(): void
    {
        $this->total = round(array_sum(array_column($this->carrito, 'subtotal')), 2);
    }

    // ── Venta ─────────────────────────────────────────────────────────────────

    public function finalizarVenta(): void
    {
        if (empty($this->carrito)) {
            Notification::make()->title('El carrito está vacío')->warning()->send();
            return;
        }

        try {
            DB::transaction(function () {
                $venta = Venta::create([
                    'cliente_id'  => $this->clienteId,
                    'subtotal'    => $this->total,
                    'descuento'   => 0,
                    'total'       => $this->total,
                    'metodo_pago' => $this->metodoPago,
                    'estado'      => 'completada',
                    'user_id'     => auth()->id(),
                ]);

                foreach ($this->carrito as $item) {
                    DetalleVenta::create([
                        'venta_id'        => $venta->id,
                        'producto_id'     => $item['id'],
                        'cantidad'        => $item['cantidad'],
                        'precio_unitario' => $item['precio'],
                        'subtotal'        => $item['subtotal'],
                    ]);
                    Producto::where('id', $item['id'])->decrement('stock', $item['cantidad']);
                }

                $this->ultimaVentaId = $venta->id;
            });

            $ventaId         = $this->ultimaVentaId;
            $this->carrito   = [];
            $this->total     = 0;
            $this->clienteId = null;

            Notification::make()->title('✅ Venta registrada')->success()->send();
            $this->dispatch('open-ticket', url: route('ticket.venta', $ventaId));

        } catch (\Exception $e) {
            Notification::make()->title('Error al procesar la venta')->body($e->getMessage())->danger()->send();
        }
    }
}

<?php

namespace App\Console\Commands;

use App\Models\Cliente;
use Illuminate\Console\Command;

class NotificarVencimientos extends Command
{
    protected $signature   = 'gym:notificar-vencimientos {--dias=5 : Días de anticipación}';
    protected $description = 'Genera los enlaces de WhatsApp para notificar clientes con membresía por vencer';

    public function handle(): void
    {
        $dias = (int) $this->option('dias');

        $clientes = Cliente::whereHas('membresiaActiva', fn ($q) =>
            $q->whereBetween('fecha_fin', [now(), now()->addDays($dias)])
        )->with('membresiaActiva.plan')->get();

        if ($clientes->isEmpty()) {
            $this->info("No hay clientes con membresía por vencer en los próximos {$dias} días.");
            return;
        }

        $this->info("=== Clientes por vencer en {$dias} días ===\n");

        $rows = $clientes->map(fn ($c) => [
            $c->nombre_completo,
            $c->telefono ?? 'Sin teléfono',
            $c->membresiaActiva->plan->nombre,
            $c->membresiaActiva->fecha_fin->format('d/m/Y'),
            $c->dias_restantes . ' días',
            $c->whatsapp_url,
        ]);

        $this->table(
            ['Cliente', 'Teléfono', 'Plan', 'Vence', 'Días Rest.', 'WhatsApp URL'],
            $rows
        );

        $this->info("\nTotal: {$clientes->count()} clientes");
    }
}

<?php

namespace App\Exports;

use App\Models\Cliente;
use Maatwebsite\Excel\Concerns\FromQuery;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithStyles;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class ClientesExport implements FromQuery, WithHeadings, WithMapping, WithStyles, ShouldAutoSize
{
    public function query()
    {
        return Cliente::with('membresiaActiva.plan')->orderBy('apellido_paterno');
    }

    public function headings(): array
    {
        return ['DNI', 'Apellido Paterno', 'Apellido Materno', 'Nombres', 'Teléfono', 'Email', 'Plan Actual', 'Vencimiento', 'Días Restantes', 'Estado'];
    }

    public function map($cliente): array
    {
        $membresia = $cliente->membresiaActiva;
        return [
            $cliente->dni,
            $cliente->apellido_paterno,
            $cliente->apellido_materno,
            $cliente->nombres,
            $cliente->telefono,
            $cliente->email,
            $membresia?->plan->nombre ?? 'Sin membresía',
            $membresia?->fecha_fin->format('d/m/Y') ?? '',
            $cliente->dias_restantes,
            match ($cliente->estado_membresia) {
                'activo'     => 'Activo',
                'por_vencer' => 'Por vencer',
                'vencido'    => 'Vencido',
                default      => 'Sin membresía',
            },
        ];
    }

    public function styles(Worksheet $sheet): array
    {
        return [1 => ['font' => ['bold' => true, 'size' => 12]]];
    }
}

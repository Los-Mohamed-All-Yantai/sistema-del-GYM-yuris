<?php

namespace App\Exports;

use App\Models\Venta;
use Maatwebsite\Excel\Concerns\FromQuery;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class VentasExport implements FromQuery, WithHeadings, WithMapping, WithStyles, ShouldAutoSize
{
    public function __construct(
        private ?string $desde = null,
        private ?string $hasta = null
    ) {}

    public function query()
    {
        $query = Venta::with('cliente', 'detalles.producto', 'vendidoPor')
            ->where('estado', 'completada');

        if ($this->desde) $query->whereDate('created_at', '>=', $this->desde);
        if ($this->hasta) $query->whereDate('created_at', '<=', $this->hasta);

        return $query->orderBy('created_at', 'desc');
    }

    public function headings(): array
    {
        return ['#Venta', 'Fecha', 'Hora', 'Cliente', 'Productos', 'Subtotal', 'Total', 'Método Pago', 'Registrado por'];
    }

    public function map($venta): array
    {
        return [
            str_pad($venta->id, 5, '0', STR_PAD_LEFT),
            $venta->created_at->format('d/m/Y'),
            $venta->created_at->format('H:i'),
            $venta->cliente?->nombre_completo ?? 'Cliente general',
            $venta->detalles->map(fn ($d) => "{$d->producto->nombre} x{$d->cantidad}")->implode(', '),
            $venta->subtotal,
            $venta->total,
            ucfirst($venta->metodo_pago),
            $venta->vendidoPor?->name ?? '',
        ];
    }

    public function styles(Worksheet $sheet): array
    {
        return [1 => ['font' => ['bold' => true, 'size' => 12]]];
    }
}

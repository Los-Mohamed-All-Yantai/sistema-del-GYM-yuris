<?php

use App\Http\Controllers\BoletaController;
use App\Http\Controllers\TicketController;
use Illuminate\Support\Facades\Route;

Route::get('/', fn () => redirect('/admin'));

// Boletas (acceso autenticado)
Route::middleware('auth')->group(function () {
    Route::get('/boleta/membresia/{membresia}', [BoletaController::class, 'membresia'])->name('boleta.membresia');
    Route::get('/boleta/venta/{venta}',         [BoletaController::class, 'venta'])->name('boleta.venta');
    Route::get('/cliente/qr/{cliente}',         [BoletaController::class, 'qrCliente'])->name('cliente.qr');

    // Tickets térmicos 72mm
    Route::get('/ticket/inscripcion/{membresia}', [TicketController::class, 'inscripcion'])->name('ticket.inscripcion');
    Route::get('/ticket/renovacion/{membresia}',  [TicketController::class, 'renovacion'])->name('ticket.renovacion');
    Route::get('/ticket/venta/{venta}',           [TicketController::class, 'venta'])->name('ticket.venta');
});

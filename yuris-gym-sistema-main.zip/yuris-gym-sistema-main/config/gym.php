<?php

return [
    'nombre'    => env('GYM_NOMBRE', "Yuri's Gym"),
    'direccion' => env('GYM_DIRECCION', ''),
    'telefono'  => env('GYM_TELEFONO', ''),
    'ciudad'    => env('GYM_CIUDAD', 'Cusco'),
    'pais'      => env('GYM_PAIS', 'Perú'),
    'moneda'    => env('GYM_MONEDA', 'PEN'),
    'whatsapp'  => env('GYM_WHATSAPP', ''),
    'maps_url'  => env('GYM_MAPS_URL', ''),
];

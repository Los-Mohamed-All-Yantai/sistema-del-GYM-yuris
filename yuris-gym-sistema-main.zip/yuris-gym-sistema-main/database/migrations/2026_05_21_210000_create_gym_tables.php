<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Planes de membresía configurables por gimnasio
        Schema::create('planes', function (Blueprint $table) {
            $table->id();
            $table->string('nombre'); // Mensual, Trimestral, Trotadora, etc.
            $table->string('descripcion')->nullable();
            $table->decimal('precio', 8, 2);
            $table->integer('duracion_dias'); // 1, 30, 90, 180
            $table->boolean('activo')->default(true);
            $table->timestamps();
        });

        // Clientes del gimnasio
        Schema::create('clientes', function (Blueprint $table) {
            $table->id();
            $table->string('dni', 15)->unique();
            $table->string('nombres');
            $table->string('apellido_paterno');
            $table->string('apellido_materno')->nullable();
            $table->string('telefono', 15)->nullable();
            $table->string('email')->nullable();
            $table->date('fecha_nacimiento')->nullable();
            $table->string('foto')->nullable();
            $table->string('codigo_qr')->unique()->nullable(); // para acceso
            $table->boolean('activo')->default(true);
            $table->timestamps();
        });

        // Membresías (historial de inscripciones/renovaciones)
        Schema::create('membresias', function (Blueprint $table) {
            $table->id();
            $table->foreignId('cliente_id')->constrained('clientes')->cascadeOnDelete();
            $table->foreignId('plan_id')->constrained('planes');
            $table->date('fecha_inicio');
            $table->date('fecha_fin');
            $table->decimal('precio_pagado', 8, 2);
            $table->enum('metodo_pago', ['efectivo', 'yape', 'plin', 'transferencia']);
            $table->string('voucher')->nullable(); // ruta imagen comprobante
            $table->enum('estado', ['activa', 'vencida', 'cancelada'])->default('activa');
            $table->text('observaciones')->nullable();
            $table->foreignId('user_id')->nullable()->constrained('users'); // quien registró
            $table->timestamps();
        });

        // Categorías de productos
        Schema::create('categorias', function (Blueprint $table) {
            $table->id();
            $table->string('nombre');
            $table->timestamps();
        });

        // Productos del inventario
        Schema::create('productos', function (Blueprint $table) {
            $table->id();
            $table->foreignId('categoria_id')->nullable()->constrained('categorias')->nullOnDelete();
            $table->string('codigo')->nullable()->unique();
            $table->string('nombre');
            $table->string('marca')->nullable();
            $table->string('descripcion')->nullable();
            $table->decimal('precio_compra', 8, 2)->default(0);
            $table->decimal('precio_venta', 8, 2);
            $table->integer('stock')->default(0);
            $table->integer('stock_minimo')->default(5);
            $table->string('proveedor')->nullable();
            $table->boolean('activo')->default(true);
            $table->timestamps();
        });

        // Ventas (cabecera)
        Schema::create('ventas', function (Blueprint $table) {
            $table->id();
            $table->foreignId('cliente_id')->nullable()->constrained('clientes')->nullOnDelete();
            $table->decimal('subtotal', 8, 2)->default(0);
            $table->decimal('descuento', 8, 2)->default(0);
            $table->decimal('total', 8, 2);
            $table->enum('metodo_pago', ['efectivo', 'yape', 'plin', 'transferencia']);
            $table->string('voucher')->nullable();
            $table->enum('estado', ['completada', 'anulada'])->default('completada');
            $table->foreignId('user_id')->nullable()->constrained('users');
            $table->timestamps();
        });

        // Detalle de ventas
        Schema::create('detalle_ventas', function (Blueprint $table) {
            $table->id();
            $table->foreignId('venta_id')->constrained('ventas')->cascadeOnDelete();
            $table->foreignId('producto_id')->constrained('productos');
            $table->integer('cantidad');
            $table->decimal('precio_unitario', 8, 2);
            $table->decimal('subtotal', 8, 2);
        });

        // Asistencias (control de acceso)
        Schema::create('asistencias', function (Blueprint $table) {
            $table->id();
            $table->foreignId('cliente_id')->constrained('clientes')->cascadeOnDelete();
            $table->foreignId('membresia_id')->nullable()->constrained('membresias')->nullOnDelete();
            $table->timestamp('entrada_at');
            $table->timestamp('salida_at')->nullable();
            $table->enum('tipo_acceso', ['qr', 'manual'])->default('manual');
            $table->timestamps();
        });

        // Medidas corporales de clientes
        Schema::create('medidas_corporales', function (Blueprint $table) {
            $table->id();
            $table->foreignId('cliente_id')->constrained('clientes')->cascadeOnDelete();
            $table->date('fecha');
            $table->decimal('peso', 5, 2)->nullable(); // kg
            $table->decimal('estatura', 5, 2)->nullable(); // cm
            $table->decimal('imc', 5, 2)->nullable();
            $table->decimal('grasa_corporal', 5, 2)->nullable(); // %
            $table->decimal('masa_muscular', 5, 2)->nullable(); // kg
            $table->decimal('cintura', 5, 2)->nullable(); // cm
            $table->decimal('cadera', 5, 2)->nullable(); // cm
            $table->text('notas')->nullable();
            $table->foreignId('user_id')->nullable()->constrained('users');
            $table->timestamps();
        });

        // Caja diaria (cierres de caja)
        Schema::create('cierres_caja', function (Blueprint $table) {
            $table->id();
            $table->date('fecha');
            $table->decimal('efectivo_sistema', 8, 2)->default(0);
            $table->decimal('yape_sistema', 8, 2)->default(0);
            $table->decimal('plin_sistema', 8, 2)->default(0);
            $table->decimal('transferencia_sistema', 8, 2)->default(0);
            $table->decimal('efectivo_real', 8, 2)->nullable();
            $table->decimal('diferencia', 8, 2)->nullable();
            $table->text('observaciones')->nullable();
            $table->foreignId('user_id')->constrained('users');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('cierres_caja');
        Schema::dropIfExists('medidas_corporales');
        Schema::dropIfExists('asistencias');
        Schema::dropIfExists('detalle_ventas');
        Schema::dropIfExists('ventas');
        Schema::dropIfExists('productos');
        Schema::dropIfExists('categorias');
        Schema::dropIfExists('membresias');
        Schema::dropIfExists('clientes');
        Schema::dropIfExists('planes');
    }
};

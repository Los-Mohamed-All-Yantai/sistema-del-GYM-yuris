<?php

namespace Database\Seeders;

use App\Models\Plan;
use Illuminate\Database\Seeder;

class PlanesSeeder extends Seeder
{
    public function run(): void
    {
        $planes = [
            ['nombre' => 'Sesión Normal',          'precio' => 10.00,  'duracion_dias' => 1,   'descripcion' => 'Acceso por un día'],
            ['nombre' => 'Sesión Trotadora',        'precio' => 15.00,  'duracion_dias' => 1,   'descripcion' => 'Acceso por un día con trotadora'],
            ['nombre' => 'Mensual Intermediario',   'precio' => 70.00,  'duracion_dias' => 30,  'descripcion' => 'Plan mensual especial'],
            ['nombre' => 'Mensual',                 'precio' => 100.00, 'duracion_dias' => 30,  'descripcion' => 'Plan mensual completo'],
            ['nombre' => 'Mensual + Trotadora',     'precio' => 130.00, 'duracion_dias' => 30,  'descripcion' => 'Plan mensual con acceso a trotadora'],
            ['nombre' => 'Trimestral',              'precio' => 240.00, 'duracion_dias' => 90,  'descripcion' => 'Plan tres meses'],
            ['nombre' => 'Semestral',               'precio' => 400.00, 'duracion_dias' => 180, 'descripcion' => 'Plan seis meses'],
        ];

        foreach ($planes as $plan) {
            Plan::firstOrCreate(['nombre' => $plan['nombre']], $plan);
        }
    }
}

<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class RolesSeeder extends Seeder
{
    public function run(): void
    {
        app()[\Spatie\Permission\PermissionRegistrar::class]->forgetCachedPermissions();

        $permisos = [
            'ver dashboard',
            'gestionar clientes', 'ver clientes',
            'gestionar membresias', 'ver membresias',
            'gestionar productos', 'ver productos',
            'gestionar ventas', 'ver ventas',
            'gestionar asistencias', 'ver asistencias',
            'gestionar medidas', 'ver medidas',
            'gestionar caja', 'ver reportes',
            'gestionar usuarios', 'gestionar planes',
        ];

        foreach ($permisos as $permiso) {
            Permission::firstOrCreate(['name' => $permiso]);
        }

        $admin = Role::firstOrCreate(['name' => 'admin']);
        $admin->syncPermissions(Permission::all());

        $recepcionista = Role::firstOrCreate(['name' => 'recepcionista']);
        $recepcionista->syncPermissions([
            'ver dashboard', 'gestionar clientes', 'ver clientes',
            'gestionar membresias', 'ver membresias',
            'ver productos', 'gestionar ventas', 'ver ventas',
            'gestionar asistencias', 'ver asistencias',
            'gestionar medidas', 'ver medidas',
        ]);

        // Usuario admin principal
        $adminUser = User::firstOrCreate(
            ['email' => 'admin@gympro.pe'],
            [
                'name' => 'Administrador',
                'password' => Hash::make('admin123'),
                'email_verified_at' => now(),
            ]
        );
        $adminUser->assignRole('admin');

        // Usuario recepcionista demo
        $recepUser = User::firstOrCreate(
            ['email' => 'recepcion@gympro.pe'],
            [
                'name' => 'Recepcionista',
                'password' => Hash::make('recep123'),
                'email_verified_at' => now(),
            ]
        );
        $recepUser->assignRole('recepcionista');
    }
}

<?php

namespace Database\Seeders;

use App\Models\Categoria;
use Illuminate\Database\Seeder;

class CategoriasSeeder extends Seeder
{
    public function run(): void
    {
        $categorias = ['Proteínas', 'Creatina', 'Pre-Entreno', 'Vitaminas', 'Aminoácidos', 'Bebidas', 'Snacks', 'Otros'];
        foreach ($categorias as $nombre) {
            Categoria::firstOrCreate(['nombre' => $nombre]);
        }
    }
}
